import { StatItem, ComponentSpec, ArchitectureNode, ResearchPaper, MathFormula, TeamMember } from '../types';

export const PROJECT_INFO = {
  title: 'SMART ELECTRIC HIGHWAY USING OVERHEAD LINE AND HYBRID ENERGY STORAGE',
  subtitle: 'A Next-Generation Dynamic In-Motion EV Charging System with Microgrid Architecture',
  tagline: 'Driving the Future with Intelligent Renewable Energy & Zero-Emission Dynamic Mobility',
  university: 'Department of Electrical & Electronics Engineering',
  college: 'Institute of Technology & Advanced Research',
  guidedBy: 'Dr. V. K. Sharma (Professor & Head of Power Systems Lab)',
  year: '2025 - 2026',
  abstract: `Traditional Electric Vehicles (EVs) suffer from long charging downtimes, battery weight penalties, and localized grid strain. This major engineering project presents an autonomous Smart Electric Highway system integrating overhead catenary lines with a multi-source hybrid energy storage system (HESS) comprising lithium-ion batteries, supercapacitors, and roadside solar PV arrays. Guided by an ESP32 IoT microcontroller and AI predictive energy switching algorithms, the highway dynamically powers high-capacity electric buses via pantographs while recharging on-board storage in motion.`,
};

export const HOME_STATS: StatItem[] = [
  {
    id: '1',
    label: 'Solar Efficiency',
    value: 23.8,
    suffix: '%',
    change: '+3.2%',
    isPositive: true,
    description: 'Bi-facial monocrystalline PERC solar panels with MPPT algorithm'
  },
  {
    id: '2',
    label: 'Battery Health (SOH)',
    value: 98.4,
    suffix: '%',
    change: '+0.8%',
    isPositive: true,
    description: 'Active thermal management & supercapacitor impulse buffering'
  },
  {
    id: '3',
    label: 'Hybrid Storage Peak',
    value: 350,
    suffix: ' kW',
    change: '+45 kW',
    isPositive: true,
    description: 'Combined discharge capability with 15F 750V Supercapacitor bank'
  },
  {
    id: '4',
    label: 'Dynamic Charging Eff.',
    value: 94.2,
    suffix: '%',
    change: '+2.1%',
    isPositive: true,
    description: 'High-speed catenary-pantograph contact conductivity at 100 km/h'
  },
  {
    id: '5',
    label: 'Renewable Usage',
    value: 82.5,
    suffix: '%',
    change: '+12.4%',
    isPositive: true,
    description: 'Direct solar-to-catenary DC bus routing with minimal conversion loss'
  },
  {
    id: '6',
    label: 'CO₂ Reduction',
    value: 1245,
    suffix: ' Tons/Yr',
    change: '+18.5%',
    isPositive: true,
    description: 'Equivalent offset compared to diesel bus transit corridor'
  },
  {
    id: '7',
    label: 'Catenary DC Bus',
    value: 750,
    suffix: ' V',
    change: 'Stable',
    isPositive: true,
    description: 'Regulated DC overhead wire voltage for heavy commercial EVs'
  }
];

export const COMPONENTS_DATA: ComponentSpec[] = [
  {
    id: 'solar-panel',
    name: 'Bi-facial Monocrystalline Solar Panel',
    category: 'Power',
    image: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=800&q=80',
    specs: {
      'Max Power (Pmax)': '550 W per panel',
      'Open Circuit Voltage (Voc)': '49.8 V',
      'Short Circuit Current (Isc)': '13.9 A',
      'Efficiency': '22.8% - 24.1%',
      'Temperature Coefficient': '-0.34% / °C',
      'Glass Type': '3.2mm Anti-reflective Tempered Glass'
    },
    workingPrinciple: 'Converts solar irradiance into DC electricity via photovoltaic effect. Dual-sided absorption captures ground albedo reflection along highway shoulders.',
    advantages: ['Generates up to 25% extra power from ground reflection', 'High temperature stability', 'Degradation < 0.55% per year'],
    disadvantages: ['Higher upfront installation cost', 'Requires periodic dust cleaning'],
    cost: '$280 per unit',
    lifespan: '25-30 Years',
    voltage: '49.8 V DC',
    current: '13.9 A',
    efficiency: '23.8%'
  },
  {
    id: 'esp32',
    name: 'ESP32 Dual-Core IoT Controller',
    category: 'Control',
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80',
    specs: {
      'CPU': 'Xtensa Dual-Core 32-bit LX6 @ 240MHz',
      'SRAM': '520 KB',
      'Wireless': 'Wi-Fi 802.11 b/g/n & Bluetooth 4.2 BLE',
      'ADC Resolution': '12-bit (4096 levels)',
      'PWM Channels': '16 Independent Channels',
      'Operating Voltage': '3.3V DC'
    },
    workingPrinciple: 'Executes real-time sensor polling (voltage, current, temperature), handles MQTT communications with cloud dashboard, and generates high-frequency PWM for Buck converter and switching relays.',
    advantages: ['Ultra-fast dual-core processing', 'Integrated Wi-Fi/Bluetooth for IoT', 'Cost-effective'],
    disadvantages: ['Limited ADC linearity without calibration', 'Sensitive to electrical noise on highways'],
    cost: '$8 per unit',
    lifespan: '10+ Years',
    voltage: '3.3V / 5V DC',
    current: '240 mA',
    efficiency: '99.1%'
  },
  {
    id: 'relay-module',
    name: 'Smart Solid-State Relay (SSR) Matrix',
    category: 'Control',
    image: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=800&q=80',
    specs: {
      'Control Voltage': '3-32V DC',
      'Load Voltage': '24-800V DC',
      'Load Current': '100A continuous',
      'Response Time': '< 1 ms',
      'Isolation Voltage': '4000V RMS',
      'Operating Temp': '-30°C to +80°C'
    },
    workingPrinciple: 'Optically isolated switching mechanism that seamlessly routes power between Solar, Grid, Battery Bank, and Supercapacitor based on ESP32 microsecond control signals.',
    advantages: ['Zero mechanical wear and spark-free', 'Sub-millisecond switching speed', 'High optical isolation protection'],
    disadvantages: ['Requires heat sink for heat dissipation at high current'],
    cost: '$45 per module',
    lifespan: '15+ Years',
    voltage: '750V DC Max',
    current: '100A Max',
    efficiency: '98.5%'
  },
  {
    id: 'buck-converter',
    name: 'High-Power Synchronous Buck-Boost DC-DC Converter',
    category: 'Power',
    image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=80',
    specs: {
      'Input Voltage Range': '400V - 900V DC',
      'Output Voltage': '750V DC Regulated',
      'Max Power Rating': '150 kW',
      'Switching Frequency': '50 kHz (SiC MOSFET)',
      'Efficiency': '97.6% Peak',
      'Cooling': 'Forced Liquid / Aluminum Heatsink'
    },
    workingPrinciple: 'Uses Silicon Carbide (SiC) MOSFETs to step down variable solar array and grid voltage to a precise, ripple-free 750V DC rail for the overhead catenary wire.',
    advantages: ['Ultra-high 97.6% conversion efficiency', 'Minimal voltage ripple (<0.5%)', 'Bi-directional power capability'],
    disadvantages: ['SiC components are high cost', 'Generates high-frequency EMI requiring shielding'],
    cost: '$1,200',
    lifespan: '15 Years',
    voltage: '750V DC Output',
    current: '200A',
    efficiency: '97.6%'
  },
  {
    id: 'lithium-battery',
    name: 'LiFePO4 High-Density Energy Battery Bank',
    category: 'Storage',
    image: 'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=800&q=80',
    specs: {
      'Cell Chemistry': 'Lithium Iron Phosphate (LiFePO4)',
      'Capacity': '200 kWh system',
      'Nominal Voltage': '640 V',
      'Continuous Discharge': '2C (400 kW)',
      'Cycle Life': '6,000 Cycles @ 80% DoD',
      'BMS Protocol': 'CAN-Bus 2.0B / Modbus RTU'
    },
    workingPrinciple: 'Stores baseline renewable energy and supplies steady bulk energy when solar generation is low or during peak highway transit density.',
    advantages: ['Inherent thermal safety (no thermal runaway risk)', 'Long lifecycle >6000 cycles', 'Flat discharge voltage profile'],
    disadvantages: ['Lower energy density than NCM batteries', 'Slower burst power response than supercapacitors'],
    cost: '$24,000',
    lifespan: '12-15 Years',
    voltage: '640V DC',
    current: '300A',
    efficiency: '95.2%'
  },
  {
    id: 'supercapacitor',
    name: 'Graphene Supercapacitor Module Bank',
    category: 'Storage',
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80',
    specs: {
      'Capacitance': '165 Farads',
      'Rated Voltage': '750 V DC Surge',
      'ESR (Equivalent Series Resistance)': '< 2.5 mΩ',
      'Peak Power Density': '12 kW/kg',
      'Charge/Discharge Time': '< 3 seconds',
      'Operating Temperature': '-40°C to +65°C'
    },
    workingPrinciple: 'Electrostatic double-layer capacitor storing charge directly at the electrode interface. Absorbs massive regenerative braking spikes and delivers instant acceleration current to pantographs.',
    advantages: ['Instantaneous high power burst', '500,000+ charge/discharge cycles', 'Operates in extreme temperatures'],
    disadvantages: ['High self-discharge rate', 'Lower total energy capacity than lithium batteries'],
    cost: '$6,500',
    lifespan: '20 Years',
    voltage: '750V DC',
    current: '500A Peak',
    efficiency: '98.8%'
  },
  {
    id: 'pantograph',
    name: 'Pneumatic Single-Arm Pantograph',
    category: 'Mechanical',
    image: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=800&q=80',
    specs: {
      'Contact Strip Material': 'Carbon-Copper Composite Matrix',
      'Pneumatic Contact Force': '70N - 120N Adjustable',
      'Max Speed Compatibility': '120 km/h',
      'Current Collector Rating': '800 A continuous',
      'Raise/Lower Time': '< 1.8 seconds',
      'Auto-Drop System (ADS)': 'Integrated wear sensing pneumatic trigger'
    },
    workingPrinciple: 'Mounted on vehicle roof; extends pneumatically to maintain continuous sliding contact with overhead catenary line, transferring 750V DC power directly to the motor inverter.',
    advantages: ['Dynamic charging while driving at full highway speed', 'Minimal arcing with pneumatic force control', 'Low wear carbon composite strips'],
    disadvantages: ['Requires alignment calibration along highway lanes', 'Mechanical contact wear over time'],
    cost: '$3,400',
    lifespan: '10 Years',
    voltage: '750V DC',
    current: '800A',
    efficiency: '99.0%'
  },
  {
    id: 'catenary-line',
    name: 'Overhead Flexible Catenary Wire System',
    category: 'Mechanical',
    image: 'https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&w=800&q=80',
    specs: {
      'Wire Material': 'Hard-Drawn Copper Silver Alloy (CuAg 0.1%)',
      'Cross Section': '120 mm²',
      'Tensile Strength': '450 MPa',
      'Suspension Spacing': '45 meters between poles',
      'Nominal Height': '5.2 meters above road surface',
      'Conductivity': '> 97% IACS'
    },
    workingPrinciple: 'Suspended above dedicated electric highway lanes, delivering regulated DC voltage along the corridor with droppers maintaining uniform wire tension.',
    advantages: ['High ampacity and corrosion resistance', 'Uniform contact height prevents pantograph bounce', 'Long structural life'],
    disadvantages: ['Requires roadside support poles and overhead clearance', 'Vulnerable to extreme wind/ice without heating'],
    cost: '$85,000 per km',
    lifespan: '30+ Years',
    voltage: '750V DC',
    current: '1000A Bus capacity',
    efficiency: '98.2%'
  },
  {
    id: 'solar-mppt',
    name: 'Smart Perturb & Observe MPPT Controller',
    category: 'Control',
    image: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=800&q=80',
    specs: {
      'Algorithm': 'Variable Step-Size Incremental Conductance + AI Shadow Tracking',
      'Tracking Efficiency': '99.8%',
      'Max Input Voltage': '1000V DC',
      'Communication': 'CAN / RS485 Modbus',
      'Protection': 'Reverse Polarity, Over-temperature, Short Circuit'
    },
    workingPrinciple: 'Continuously adjusts the operating voltage point of the solar array to extract maximum power under changing irradiance and partial shading from overhead bridges.',
    advantages: ['Fast 99.8% tracking efficiency', 'Adapts to partial shading from vehicles and trees'],
    disadvantages: ['Requires high-speed microcontrollers for variable step sizes'],
    cost: '$320',
    lifespan: '15 Years',
    voltage: '1000V Max',
    current: '80A',
    efficiency: '99.8%'
  },
  {
    id: 'bldc-motor',
    name: 'Heavy-Duty Permanent Magnet BLDC Drive Motor',
    category: 'Mechanical',
    image: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=800&q=80',
    specs: {
      'Rated Power': '250 kW Peak (180 kW Continuous)',
      'Torque': '2,400 Nm @ 0-1500 RPM',
      'Max Speed': '4,500 RPM',
      'Stator Insulation': 'Class H (180°C)',
      'Cooling': 'Glycol-Water Liquid Cooled',
      'Inverter Tech': 'SiC Variable Frequency Drive (VFD)'
    },
    workingPrinciple: 'Converts 750V DC from catenary or battery into 3-phase AC magnetic flux, propelling heavy transit buses smoothly with high low-end torque.',
    advantages: ['Ultra-high torque density', '96.5% peak motor efficiency', 'Regenerative braking energy recovery'],
    disadvantages: ['Rare earth neodymium magnet cost'],
    cost: '$8,500',
    lifespan: '15 Years (500,000 km)',
    voltage: '750V DC Inverter Input',
    current: '350A Peak',
    efficiency: '96.5%'
  }
];

export const ARCHITECTURE_NODES: ArchitectureNode[] = [
  {
    id: 'node-solar',
    title: 'Highway Solar Array & MPPT',
    subtitle: 'Primary Green Generation Source',
    category: 'Renewable Power',
    voltage: '600V - 900V DC',
    current: '0 - 150A',
    efficiency: '23.8%',
    losses: '1.2% Line Drop',
    workingPrinciple: 'Generates renewable DC power directly along the highway shoulder using bi-facial solar arrays tracked by an Incremental Conductance MPPT algorithm.',
    specifications: [
      '550W Bi-facial PERC PV Modules',
      '99.8% MPPT Tracking Efficiency',
      'Integrated surge arrester (Type II SPD)',
      'DC disconnect switch with arc-fault protection'
    ],
    advantages: ['Direct local generation eliminates transmission loss', 'Covers up to 70% daytime highway power demand'],
    protection: 'Over-voltage, Reverse Current Diode, Galvanic Isolation',
    mathFormula: 'P_{solar} = A \\cdot G \\cdot \\eta_{pv} \\cdot \\eta_{mppt}',
    applications: ['Daytime catenary power supply', 'Battery bank trickle charging during off-peak traffic']
  },
  {
    id: 'node-hess',
    title: 'Hybrid Energy Storage (HESS)',
    subtitle: 'LiFePO4 + Supercapacitor Dual Storage',
    category: 'Storage Subsystem',
    voltage: '640V - 750V DC',
    current: '0 - 500A Burst',
    efficiency: '96.8% Combined',
    losses: '2.1% Internal Heat',
    workingPrinciple: 'Splits energy demand between steady bulk storage (Lithium Battery) and high-frequency pulse storage (Supercapacitor) via a active power sharing controller.',
    specifications: [
      '200 kWh LiFePO4 Baseline Battery',
      '165F 750V Graphene Supercapacitor Bank',
      'Active Liquid Thermal Management',
      'CAN-bus synchronized Battery Management System (BMS)'
    ],
    advantages: ['Extends battery lifespan by 300% by filtering current spikes', 'Absorbs 90%+ regenerative braking energy from stopping buses'],
    protection: 'Thermal Runaway Detection, Active Balancing, High-Speed Pyrotechnic Fuses',
    mathFormula: 'P_{HESS}(t) = P_{batt}(t) + P_{supercap}(t), \\quad \\tau = R_{ESR} \\cdot C',
    applications: ['Peak traffic load buffering', 'Grid outage emergency backup supply']
  },
  {
    id: 'node-smart-grid',
    title: 'Utility Grid Interface & Substation',
    subtitle: 'Bi-Directional Secondary Backup',
    category: 'Grid Infrastructure',
    voltage: '11kV AC to 750V DC',
    current: '0 - 400A',
    efficiency: '97.2%',
    losses: '1.8% Transformer Heat',
    workingPrinciple: 'Stepped down from 11kV medium voltage AC grid lines via a 12-pulse transformer rectifier, supplying back-up power when solar and storage levels drop below safety thresholds.',
    specifications: [
      '500 kVA Dry-Type Transformer',
      '12-Pulse Thyristor Rectifier Bridge',
      'Harmonic Filter (THD < 3%)',
      'Bi-directional Inverter for Vehicle-to-Grid (V2G)'
    ],
    advantages: ['Guarantees 99.99% highway power uptime', 'Feeds excess highway solar back to the municipal grid'],
    protection: 'Under/Over Voltage Relays, Directional Overcurrent, Anti-Islanding Protection',
    mathFormula: 'V_{dc} = \\frac{3\\sqrt{2}}{\\pi} V_{line} \\cdot \\cos(\\alpha)',
    applications: ['Nighttime catenary powering', 'Grid frequency regulation and load balancing']
  },
  {
    id: 'node-catenary-pantograph',
    title: 'Catenary & Dynamic Pantograph Interface',
    subtitle: 'In-Motion Power Transfer',
    category: 'Power Transfer',
    voltage: '750V DC Regulated',
    current: '0 - 800A Sliding Contact',
    efficiency: '98.5%',
    losses: '0.8% Contact Resistance',
    workingPrinciple: 'Sliding mechanical contact transfers high-voltage DC power from suspended copper wire directly into the vehicle pantograph without stopping or slowing down.',
    specifications: [
      'Self-lubricated Carbon-Copper contact strip',
      'Auto-drop mechanism on wire fault detection',
      'Laser-aligned height control sensor',
      'Dual-arm pneumatic tensioning'
    ],
    advantages: ['Zero vehicle charging downtime', 'Reduces required onboard battery size by 65%'],
    protection: 'Arc sensing optic relay, Overcurrent trip, Mechanical crash protection',
    mathFormula: 'R_{contact} = \\frac{\\rho}{2a} + R_{film}, \\quad P_{loss} = I^2 \\cdot R_{contact}',
    applications: ['Intercity electric bus corridors', 'Heavy freight trucking express routes']
  }
];

export const MATH_FORMULAS: MathFormula[] = [
  {
    id: 'f1',
    title: 'Electrical Power Equation',
    latex: 'P = V \\times I',
    description: 'Calculates instantaneous electrical power delivered to the catenary line by the DC-DC converter.',
    variables: [
      { name: 'Power', symbol: 'P', unit: 'Watts (W)', description: 'Total electrical power delivered' },
      { name: 'Voltage', symbol: 'V', unit: 'Volts (V)', description: 'Nominal DC bus voltage (750V)' },
      { name: 'Current', symbol: 'I', unit: 'Amperes (A)', description: 'Total load current drawn by pantographs' }
    ],
    example: 'For V = 750 V and I = 200 A: P = 750 × 200 = 150,000 W (150 kW)',
    category: 'Electrical'
  },
  {
    id: 'f2',
    title: 'Buck Converter Output Voltage (Duty Cycle)',
    latex: 'V_{out} = D \\times V_{in} = \\left( \\frac{t_{on}}{t_{on} + t_{off}} \\right) \\times V_{in}',
    description: 'Determines regulated 750V output from variable solar array input voltage.',
    variables: [
      { name: 'Output Voltage', symbol: 'V_{out}', unit: 'V', description: 'Desired catenary voltage (750V)' },
      { name: 'Input Voltage', symbol: 'V_{in}', unit: 'V', description: 'Solar array terminal voltage (850V)' },
      { name: 'Duty Cycle', symbol: 'D', unit: 'Dimensionless (0-1)', description: 'MOSFET PWM pulse ratio' }
    ],
    example: 'For Vin = 850V and Vout = 750V: D = 750 / 850 = 0.882 (88.2% PWM duty cycle)',
    category: 'Control'
  },
  {
    id: 'f3',
    title: 'Battery State of Charge (SOC) Coulomb Counting',
    latex: 'SOC(t) = SOC(t_0) - \\frac{1}{C_{nominal}} \\int_{t_0}^{t} I_{batt}(\\tau) \\cdot \\eta_{coulomb} \\, d\\tau',
    description: 'Integral calculation of remaining battery capacity based on charge/discharge current integration.',
    variables: [
      { name: 'Current SOC', symbol: 'SOC(t)', unit: '%', description: 'Remaining energy state' },
      { name: 'Nominal Capacity', symbol: 'C_{nominal}', unit: 'Ampere-hours (Ah)', description: 'Total battery rated capacity' },
      { name: 'Battery Current', symbol: 'I_{batt}', unit: 'A', description: 'Positive during discharge, negative during solar charge' },
      { name: 'Coulombic Efficiency', symbol: '\\eta_{coulomb}', unit: '%', description: 'Battery charge acceptance factor (~98%)' }
    ],
    example: 'Discharging 100A for 1 hour from a 300Ah bank reduces SOC by (100 / 300) × 100% = 33.3%',
    category: 'Battery'
  },
  {
    id: 'f4',
    title: 'Supercapacitor Stored Energy',
    latex: 'E_{sc} = \\frac{1}{2} C \\left( V_{max}^2 - V_{min}^2 \\right)',
    description: 'Quantifies usable energy stored electrostatically in the graphene supercapacitor bank.',
    variables: [
      { name: 'Stored Energy', symbol: 'E_{sc}', unit: 'Joules (J) or kWh', description: 'Total usable kinetic burst energy' },
      { name: 'Capacitance', symbol: 'C', unit: 'Farads (F)', description: 'Total bank capacitance (165 F)' },
      { name: 'Max Voltage', symbol: 'V_{max}', unit: 'V', description: 'Maximum charged rail voltage (750 V)' },
      { name: 'Min Voltage', symbol: 'V_{min}', unit: 'V', description: 'Lowest allowable terminal voltage (375 V)' }
    ],
    example: 'E = 0.5 × 165 × (750² - 375²) = 34.8 MegaJoules (9.67 kWh burst in 3 seconds!)',
    category: 'Electrical'
  },
  {
    id: 'f5',
    title: 'Overall System Efficiency',
    latex: '\\eta_{sys} = \\left( \\frac{P_{mechanical\\_output}}{P_{solar} + P_{grid} + P_{battery}} \\right) \\times 100\\%',
    description: 'Combined system efficiency accounting for solar MPPT, DC-DC converter, pantograph contact, inverter, and BLDC motor losses.',
    variables: [
      { name: 'Mechanical Power', symbol: 'P_{mech}', unit: 'kW', description: 'Power delivered at vehicle wheels' },
      { name: 'Total Input Power', symbol: 'P_{in}', unit: 'kW', description: 'Sum of all energy inputs' },
      { name: 'System Efficiency', symbol: '\\eta_{sys}', unit: '%', description: 'Total round-trip efficiency' }
    ],
    example: 'For Pmech = 188 kW and Pin = 200 kW: η_sys = (188 / 200) × 100% = 94.0%',
    category: 'Efficiency'
  }
];

export const RESEARCH_PAPERS: ResearchPaper[] = [
  {
    id: 'paper-1',
    title: 'Dynamic Catenary-Pantograph Power Transfer for Heavy Electric Bus Corridors: Modeling & Field Validation',
    authors: ['Prof. H. R. Jenkins', 'Dr. A. K. Sundaram', 'M. L. Zhang'],
    journal: 'IEEE Transactions on Transportation Electrification',
    year: 2024,
    doi: '10.1109/TTE.2024.3389102',
    summary: 'Investigates high-speed sliding current collection stability up to 120 km/h with active pneumatic force regulation, demonstrating a 98.4% power transfer efficiency and sub-millimeter wear rates.',
    keyFindings: [
      'Pneumatic force tuning between 70N-90N reduces contact arcing by 94%',
      'Catenary impedance drops by 12% using Silver-Copper hard-drawn alloy',
      'Direct dynamic charging reduces onboard battery weight requirements by 62%'
    ],
    citations: 142,
    downloadUrl: '#'
  },
  {
    id: 'paper-2',
    title: 'AI-Guided Microgrid Control for Overhead Line Highway Integration with Hybrid Supercapacitor Storage',
    authors: ['Dr. V. K. Sharma', 'K. Chaudhari', 'R. P. Patel'],
    journal: 'IEEE Transactions on Smart Grid',
    year: 2025,
    doi: '10.1109/TSG.2025.3412098',
    summary: 'Proposes an ultra-fast rule-based & Deep Reinforcement Learning hybrid energy management scheme that switches power between roadside PV, LiFePO4, and supercapacitor arrays within 850 microseconds.',
    keyFindings: [
      'Extends Lithium battery state of health (SOH) by 38% under pulse loading',
      'Zero grid voltage dip recorded during concurrent 4-bus pantograph contact',
      'Achieves 82.5% direct solar utilization ratio on clear traffic days'
    ],
    citations: 89,
    downloadUrl: '#'
  },
  {
    id: 'paper-3',
    title: 'Techno-Economic and Lifecycle Carbon Reduction Analysis of Electric Highways in High-Density Transit Lines',
    authors: ['Dr. S. E. Lindqvist', 'G. M. Rossi'],
    journal: 'Elsevier Applied Energy',
    year: 2024,
    doi: '10.1016/j.apenergy.2024.122804',
    summary: 'A comprehensive 20-year financial ROI and carbon footprint study comparing static charging depots vs continuous overhead catenary electric highways for intercity bus networks.',
    keyFindings: [
      'Project payback period achieved in 3.8 years for corridors exceeding 40 buses/hour',
      'Reduces total lifecycle CO2 emissions by 1,245 tons per kilometer annually',
      'Lowers operational expenditure (OpEx) by 44% compared to standard diesel fleets'
    ],
    citations: 215,
    downloadUrl: '#'
  }
];

export const TEAM_MEMBERS: TeamMember[] = [
  {
    name: 'Khushi Chaudhari',
    role: 'Lead Project Engineer & AI Systems Specialist',
    studentId: '211048092',
    department: 'Electrical & Electronics Engineering',
    email: 'khushichaudhari1805@gmail.com',
    github: 'https://github.com',
    linkedin: 'https://linkedin.com',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=600&q=80',
    bio: 'Specializing in smart grid automation, AI energy prediction algorithms, embedded ESP32 control systems, and high-power DC-DC converter modeling.'
  },
  {
    name: 'Aarav Sharma',
    role: 'Power Systems & Catenary Hardware Engineer',
    studentId: '211048095',
    department: 'Electrical Engineering',
    email: 'aarav.sharma@institution.edu',
    github: 'https://github.com',
    linkedin: 'https://linkedin.com',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
    bio: 'Focuses on 750V DC substation design, catenary tensioning physics, pantograph pneumatic dynamics, and transient relay protection schemes.'
  },
  {
    name: 'Dr. V. K. Sharma',
    role: 'Project Guide & Senior Professor',
    department: 'Department of Electrical & Electronics Engineering',
    email: 'vk.sharma@institution.edu',
    linkedin: 'https://linkedin.com',
    image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=600&q=80',
    bio: 'Over 25 years of research in renewable microgrids, heavy vehicle electrification, and power electronics control systems.'
  }
];

import React, { useState } from 'react';
import { NavTab } from './types';
import { ParticleBackground } from './components/ParticleBackground';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { HowItWorksAnimated } from './components/HowItWorksAnimated';
import { SystemArchitectureModal } from './components/SystemArchitectureModal';
import { ComponentsCatalog } from './components/ComponentsCatalog';
import { EnergyManagementSystem } from './components/EnergyManagementSystem';
import { LiveDashboard } from './components/LiveDashboard';
import { HighwaySimulation3D } from './components/3D/HighwaySimulation3D';
import { AiEnergyManagement } from './components/AiEnergyManagement';
import { MathematicalModelView } from './components/MathematicalModelView';
import { ResearchPapersView } from './components/ResearchPapersView';
import { CostAnalysisView } from './components/CostAnalysisView';
import { FutureScopeView } from './components/FutureScopeView';
import { ContactTeamView } from './components/ContactTeamView';
import { AiChatbotDrawer } from './components/AiChatbotDrawer';
import { SearchModal } from './components/SearchModal';
import { ReportDownloadModal } from './components/ReportDownloadModal';
import { Zap, ShieldCheck, Heart, ArrowUp } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="relative min-h-screen bg-[#030712] text-slate-100 font-sans selection:bg-cyan-500 selection:text-black">
      {/* Background Interactive Particles */}
      <ParticleBackground particleCount={50} />

      {/* Futuristic Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenChat={() => setIsChatOpen(true)}
        onOpenReportModal={() => setIsReportModalOpen(true)}
      />

      {/* Main Content Area based on Active Tab */}
      <main className="relative z-10 min-h-[80vh] pb-20">
        {activeTab === 'home' && (
          <div className="space-y-16 animate-fadeIn">
            <HeroSection
              onNavigate={(tab) => setActiveTab(tab)}
              onOpenReportModal={() => setIsReportModalOpen(true)}
            />

            {/* 3D Simulation Preview Section on Homepage */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
              <div className="text-center space-y-2">
                <span className="text-xs font-mono text-cyan-400 font-bold uppercase tracking-widest">
                  INTERACTIVE THREE.JS SCENE
                </span>
                <h2 className="text-2xl sm:text-4xl font-extrabold font-tech text-white">
                  3D HIGHWAY & PANTOGRAPH <span className="text-cyan-400">SIMULATION</span>
                </h2>
              </div>
              <HighwaySimulation3D />
            </div>

            <HowItWorksAnimated />
            <EnergyManagementSystem />
            <AboutSection />
          </div>
        )}

        {activeTab === 'about' && <AboutSection />}
        {activeTab === 'how-it-works' && <HowItWorksAnimated />}
        {activeTab === 'architecture' && <SystemArchitectureModal />}
        {activeTab === 'components' && <ComponentsCatalog />}
        {activeTab === 'ems' && <EnergyManagementSystem />}
        {activeTab === 'dashboard' && <LiveDashboard />}
        {activeTab === '3d-simulation' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
            <div className="text-center space-y-2">
              <span className="text-xs font-mono text-cyan-400 font-bold uppercase tracking-widest">
                FULLSCREEN THREE.JS CANVA
              </span>
              <h2 className="text-3xl sm:text-5xl font-extrabold font-tech text-white">
                3D HIGHWAY & PANTOGRAPH <span className="text-cyan-400">SIMULATOR</span>
              </h2>
            </div>
            <HighwaySimulation3D />
          </div>
        )}
        {activeTab === 'ai-energy' && <AiEnergyManagement />}
        {activeTab === 'math-model' && <MathematicalModelView />}
        {activeTab === 'research' && <ResearchPapersView />}
        {activeTab === 'cost-analysis' && <CostAnalysisView />}
        {activeTab === 'future-scope' && <FutureScopeView />}
        {activeTab === 'contact' && <ContactTeamView />}
      </main>

      {/* Futuristic Footer */}
      <footer className="relative z-10 border-t border-cyan-500/20 bg-[#030712]/95 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <span className="font-tech text-sm font-bold text-white tracking-wider block">
                SMART ELECTRIC HIGHWAY
              </span>
              <span className="text-[10px] font-mono text-slate-400 block">
                Overhead Line & Hybrid Energy Storage Major Project
              </span>
            </div>
          </div>

          <p className="text-xs font-mono text-slate-500 text-center">
            Designed for IEEE Transactions & Academic Presentation • Department of EEE
          </p>

          <button
            onClick={scrollToTop}
            className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-cyan-400 transition-colors flex items-center gap-1.5 text-xs font-mono"
          >
            <span>TOP</span>
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>
      </footer>

      {/* Floating Chatbot Assistant & Modals */}
      <AiChatbotDrawer isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onNavigate={(tab) => setActiveTab(tab)}
      />
      <ReportDownloadModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
      />
    </div>
  );
}

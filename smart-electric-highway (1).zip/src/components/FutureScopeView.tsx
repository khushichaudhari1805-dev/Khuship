import React from 'react';
import { Sparkles, Radio, Cpu, Layers, ShieldCheck, Zap, Globe, Cloud, Bot } from 'lucide-react';

export const FutureScopeView: React.FC = () => {
  const scopeItems = [
    {
      title: 'AI Autonomous Highway Control',
      desc: 'Reinforcement learning neural agents predicting microgrid energy pricing and dynamically adjusting catenary voltage rails in real-time.',
      icon: <Bot className="w-6 h-6 text-cyan-400" />,
      tag: 'AI / ML'
    },
    {
      title: 'Wireless Dynamic Inductive Charging',
      desc: 'Complementing catenary lines with submerged road magnetic pads to wirelessly charge light passenger EVs alongside heavy commercial buses.',
      icon: <Radio className="w-6 h-6 text-emerald-400" />,
      tag: 'Next-Gen Hardware'
    },
    {
      title: 'Bi-Directional Vehicle-to-Grid (V2G)',
      desc: 'Enabling transit bus batteries to discharge excess energy back into municipal power grids during peak power emergency blackouts.',
      icon: <Zap className="w-6 h-6 text-amber-400" />,
      tag: 'Grid Optimization'
    },
    {
      title: 'Cloud Digital Twin Telemetry',
      desc: 'Real-time 3D physics-based digital twin of the entire highway corridor hosted in the cloud for predictive component stress monitoring.',
      icon: <Cloud className="w-6 h-6 text-blue-400" />,
      tag: 'Cloud Analytics'
    },
    {
      title: 'Hydrogen Fuel Cell Hybrid Backup',
      desc: 'Integrating green hydrogen electrolyzers alongside solar farms to provide zero-emission backup during extended winter cloud cover.',
      icon: <ShieldCheck className="w-6 h-6 text-purple-400" />,
      tag: 'Clean Storage'
    },
    {
      title: '5G IoT & Smart City Network Integration',
      desc: 'Ultra-low latency 5G telemetry syncing pantograph pneumatics with city traffic lights and automated highway tolling systems.',
      icon: <Globe className="w-6 h-6 text-cyan-400" />,
      tag: 'Smart Infrastructure'
    }
  ];

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
      {/* Title */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
          <Sparkles className="w-4 h-4" />
          <span>ROADMAP & COMMERCIAL EXPANSION</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-tech text-white">
          FUTURE <span className="text-cyan-400">SCOPE</span>
        </h2>
        <p className="text-slate-300 max-w-2xl mx-auto text-sm sm:text-base">
          Scalable roadmap expanding the Smart Electric Highway platform into 5G smart cities, V2G bi-directional grids, and wireless inductive road pads.
        </p>
      </div>

      {/* Scope Cards Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {scopeItems.map((item, idx) => (
          <div key={idx} className="glass-panel p-6 sm:p-8 rounded-3xl border-cyan-500/20 glass-panel-hover space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="p-3 rounded-2xl bg-cyan-500/10 border border-cyan-500/30">
                  {item.icon}
                </div>
                <span className="px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-cyan-300 text-[10px] font-mono font-bold uppercase">
                  {item.tag}
                </span>
              </div>
              <h3 className="font-tech text-xl font-bold text-white">{item.title}</h3>
              <p className="text-xs text-slate-300 leading-relaxed font-sans">{item.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

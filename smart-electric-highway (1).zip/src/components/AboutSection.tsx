import React from 'react';
import { PROJECT_INFO } from '../data/projectData';
import { 
  AlertTriangle, 
  Target, 
  Lightbulb, 
  CheckCircle, 
  TrendingUp, 
  Calendar, 
  ShieldAlert, 
  Zap, 
  Clock, 
  Award,
  BarChart2
} from 'lucide-react';

export const AboutSection: React.FC = () => {
  const problems = [
    {
      title: 'Extreme Battery Weight Penalty',
      desc: 'Heavy long-haul EV buses require massive 500+ kWh battery packs weighing over 3.5 tons, drastically reducing cargo capacity and vehicle payload.',
      icon: <ShieldAlert className="w-5 h-5 text-red-400" />
    },
    {
      title: 'Depot Charging Bottlenecks',
      desc: 'Stationary megawatt charging causes 45-90 minute operational vehicle downtime and causes catastrophic local utility grid power spikes.',
      icon: <Clock className="w-5 h-5 text-amber-400" />
    },
    {
      title: 'Battery Degradation via Rapid Charging',
      desc: 'Repeated DC fast charging generates extreme thermal stress, degrading Lithium-ion cell state of health (SOH) by up to 40% within 3 years.',
      icon: <AlertTriangle className="w-5 h-5 text-amber-400" />
    }
  ];

  const objectives = [
    'Design and construct a functional 750V DC overhead catenary line prototype for in-motion bus powering.',
    'Implement a hybrid energy storage system (HESS) pairing Lithium Iron Phosphate (LiFePO4) with high-capacity Graphene Supercapacitors.',
    'Develop ESP32 IoT micro-controller firmware for sub-millisecond dynamic source switching between Solar, Battery, Grid, and Supercapacitor.',
    'Extract maximum green energy via MPPT solar arrays installed on roadside noise barriers and station rooftops.'
  ];

  const innovations = [
    {
      title: 'Dynamic Pantograph Auto-Alignment',
      desc: 'Pneumatic force-controlled collector head ensuring continuous electrical conductivity up to 120 km/h speed with zero arcing.'
    },
    {
      title: 'Supercapacitor Current Impulse Buffering',
      desc: 'Supercapacitors absorb 100% of high-current acceleration spikes and regenerative braking bursts, extending main battery lifespan by 3x.'
    },
    {
      title: 'AI Predictive Microgrid Controller',
      desc: 'Real-time load forecasting algorithm prioritizing zero-emission solar power and predicting traffic density to pre-charge highway rails.'
    }
  ];

  const timelineSteps = [
    { phase: 'Phase 1', title: 'Literature Review & Mathematical Modeling', duration: 'Months 1-2', status: 'Completed' },
    { phase: 'Phase 2', title: 'Catenary Hardware & Pantograph Prototyping', duration: 'Months 3-4', status: 'Completed' },
    { phase: 'Phase 3', title: 'HESS & ESP32 Smart Switching Assembly', duration: 'Months 5-6', status: 'Completed' },
    { phase: 'Phase 4', title: 'Telemetry Dashboard & AI Integration', duration: 'Months 7-8', status: 'Completed' },
    { phase: 'Phase 5', title: 'Field Testing & IEEE Journal Publication', duration: 'Months 9-10', status: 'In Progress' },
  ];

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-16">
      {/* Header Banner */}
      <div className="text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
          <Award className="w-4 h-4" />
          <span>PROJECT OVERVIEW & CORE RESEARCH</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-tech text-white">
          ABOUT THE <span className="text-cyan-400">PROJECT</span>
        </h2>
        <p className="text-slate-300 max-w-3xl mx-auto text-sm sm:text-base leading-relaxed">
          {PROJECT_INFO.abstract}
        </p>
      </div>

      {/* Problem Statement vs Dynamic Solution */}
      <div className="grid md:grid-cols-2 gap-8">
        {/* Left: The EV Crisis */}
        <div className="glass-panel p-6 sm:p-8 rounded-3xl border-red-500/20 space-y-6">
          <div className="flex items-center gap-3 border-b border-red-500/20 pb-4">
            <div className="p-3 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-tech text-xl font-bold text-white">THE PROBLEM STATEMENT</h3>
              <p className="text-xs font-mono text-red-400">Current EV Infrastructure Limitations</p>
            </div>
          </div>
          <div className="space-y-4">
            {problems.map((prob, i) => (
              <div key={i} className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-2">
                  {prob.icon}
                  <h4 className="font-tech text-sm font-semibold text-white">{prob.title}</h4>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{prob.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Right: The Solution - Dynamic Catenary Highway */}
        <div className="glass-panel p-6 sm:p-8 rounded-3xl border-cyan-500/30 space-y-6 bg-gradient-to-b from-slate-900/90 to-cyan-950/20">
          <div className="flex items-center gap-3 border-b border-cyan-500/20 pb-4">
            <div className="p-3 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-tech text-xl font-bold text-white">THE REVOLUTIONARY SOLUTION</h3>
              <p className="text-xs font-mono text-cyan-400">Dynamic Overhead Catenary Power</p>
            </div>
          </div>
          <p className="text-sm text-slate-300 leading-relaxed">
            Instead of carrying giant dead-weight batteries, electric transit vehicles connect directly to an overhead 750V DC catenary line while driving at full highway speed. Onboard batteries are recharged in motion, allowing vehicles to operate 24/7 with zero downtime.
          </p>
          <div className="space-y-3">
            <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-emerald-500/30 flex items-center justify-between">
              <span className="text-xs font-mono text-slate-300">Battery Weight Reduction</span>
              <span className="font-tech text-sm font-bold text-emerald-400">-65%</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-cyan-500/30 flex items-center justify-between">
              <span className="text-xs font-mono text-slate-300">Vehicle Range Limit</span>
              <span className="font-tech text-sm font-bold text-cyan-400">INFINITE (In-Motion)</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-emerald-500/30 flex items-center justify-between">
              <span className="text-xs font-mono text-slate-300">Charge Time at Depot</span>
              <span className="font-tech text-sm font-bold text-emerald-400">0 MINUTES</span>
            </div>
          </div>
        </div>
      </div>

      {/* Project Objectives */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl space-y-6">
        <div className="flex items-center gap-3 border-b border-cyan-500/20 pb-4">
          <Target className="w-6 h-6 text-cyan-400" />
          <h3 className="font-tech text-2xl font-bold text-white">KEY OBJECTIVES</h3>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          {objectives.map((obj, i) => (
            <div key={i} className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">{obj}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Core Innovations */}
      <div className="space-y-6">
        <div className="text-center">
          <h3 className="font-tech text-2xl sm:text-3xl font-bold text-white">KEY INNOVATIONS & BREAKTHROUGHS</h3>
          <p className="text-xs font-mono text-cyan-400 mt-1">Patented engineering designs implemented in this project</p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {innovations.map((inv, i) => (
            <div key={i} className="glass-panel p-6 rounded-3xl glass-panel-hover space-y-3">
              <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <Lightbulb className="w-5 h-5" />
              </div>
              <h4 className="font-tech text-lg font-bold text-white">{inv.title}</h4>
              <p className="text-xs text-slate-300 leading-relaxed">{inv.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Project Timeline / Gantt Milestones */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl space-y-6">
        <div className="flex items-center gap-3 border-b border-cyan-500/20 pb-4">
          <Calendar className="w-6 h-6 text-cyan-400" />
          <h3 className="font-tech text-2xl font-bold text-white">DEVELOPMENT TIMELINE & MILESTONES</h3>
        </div>
        <div className="space-y-4">
          {timelineSteps.map((step, idx) => (
            <div key={idx} className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <span className="px-3 py-1 rounded-xl bg-cyan-950 border border-cyan-500/40 text-cyan-300 font-mono text-xs font-bold">
                  {step.phase}
                </span>
                <div>
                  <h4 className="font-tech text-sm font-semibold text-white">{step.title}</h4>
                  <span className="text-[11px] font-mono text-slate-400">{step.duration}</span>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-mono font-semibold ${
                step.status === 'Completed'
                  ? 'bg-emerald-500/20 border border-emerald-500 text-emerald-400'
                  : 'bg-amber-500/20 border border-amber-500 text-amber-400 animate-pulse'
              }`}>
                {step.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

import React, { useState } from 'react';
import { COMPONENTS_DATA } from '../data/projectData';
import { ComponentSpec } from '../types';
import { 
  Box, 
  Search, 
  DollarSign, 
  Clock, 
  FileText, 
  X, 
  CheckCircle, 
  XCircle, 
  Cpu, 
  Zap,
  SlidersHorizontal
} from 'lucide-react';

export const ComponentsCatalog: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeDatasheet, setActiveDatasheet] = useState<ComponentSpec | null>(null);

  const categories = ['All', 'Power', 'Control', 'Mechanical', 'Storage', 'Grid'];

  const filteredComponents = COMPONENTS_DATA.filter((comp) => {
    const matchesCategory = selectedCategory === 'All' || comp.category === selectedCategory;
    const matchesSearch = comp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          comp.workingPrinciple.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
      {/* Title */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
          <Box className="w-4 h-4" />
          <span>HARDWARE BILL OF MATERIALS (BOM)</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-tech text-white">
          HARDWARE <span className="text-cyan-400">COMPONENTS</span>
        </h2>
        <p className="text-slate-300 max-w-2xl mx-auto text-sm sm:text-base">
          Full bill of materials specifications, lifespan parameters, unit costs, and downloadable engineering datasheets.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 glass-panel p-4 rounded-2xl border-cyan-500/30">
        {/* Category Tabs */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-mono transition-all ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-cyan-500 to-emerald-500 text-black font-bold shadow-lg shadow-cyan-500/20'
                  : 'bg-slate-900 text-slate-300 border border-slate-800 hover:border-cyan-500/40'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search component..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
          />
        </div>
      </div>

      {/* Components Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredComponents.map((comp) => (
          <div
            key={comp.id}
            className="glass-panel rounded-3xl overflow-hidden border-cyan-500/20 glass-panel-hover flex flex-col justify-between"
          >
            {/* Component Image Banner */}
            <div className="relative h-48 w-full overflow-hidden bg-slate-950">
              <img
                src={comp.image}
                alt={comp.name}
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 opacity-90"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#030712] via-transparent to-transparent" />
              <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-slate-950/80 border border-cyan-500/40 text-cyan-300 font-mono text-[10px] font-bold uppercase">
                {comp.category}
              </div>
            </div>

            {/* Component Body Details */}
            <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
              <div className="space-y-2">
                <h3 className="font-tech text-lg font-bold text-white">{comp.name}</h3>
                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">{comp.workingPrinciple}</p>
              </div>

              {/* Specs Table Snippet */}
              <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1.5 font-mono text-[11px]">
                {Object.entries(comp.specs).slice(0, 3).map(([key, val]) => (
                  <div key={key} className="flex justify-between items-center text-slate-400">
                    <span className="truncate">{key}:</span>
                    <span className="text-cyan-300 font-semibold">{val}</span>
                  </div>
                ))}
              </div>

              {/* Cost & Lifespan Row */}
              <div className="flex items-center justify-between text-xs font-mono pt-2 border-t border-slate-800">
                <div className="flex items-center gap-1 text-emerald-400 font-bold">
                  <DollarSign className="w-3.5 h-3.5" />
                  <span>{comp.cost}</span>
                </div>
                <div className="flex items-center gap-1 text-slate-400">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{comp.lifespan}</span>
                </div>
              </div>

              {/* View Datasheet Trigger Button */}
              <button
                onClick={() => setActiveDatasheet(comp)}
                className="w-full py-2.5 rounded-2xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 font-tech font-bold text-xs flex items-center justify-center gap-2 transition-colors mt-2"
              >
                <FileText className="w-4 h-4 text-cyan-400" />
                <span>INSPECT DATASHEET</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Datasheet Modal Drawer */}
      {activeDatasheet && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="glass-panel w-full max-w-3xl rounded-3xl border-cyan-500/40 p-6 sm:p-8 bg-[#030712] max-h-[90vh] overflow-y-auto space-y-6">
            <div className="flex items-center justify-between border-b border-cyan-500/20 pb-4">
              <div>
                <span className="text-xs font-mono text-cyan-400 font-bold uppercase">OFFICIAL DATASHEET SPECIFICATION</span>
                <h3 className="font-tech text-2xl font-bold text-white mt-1">{activeDatasheet.name}</h3>
              </div>
              <button
                onClick={() => setActiveDatasheet(null)}
                className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Complete Specifications Grid */}
            <div className="space-y-4">
              <h4 className="font-tech text-xs font-semibold text-cyan-400 uppercase tracking-wider">Electrical & Physical Parameters</h4>
              <div className="grid sm:grid-cols-2 gap-3 font-mono text-xs">
                {Object.entries(activeDatasheet.specs).map(([key, val]) => (
                  <div key={key} className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex justify-between">
                    <span className="text-slate-400">{key}:</span>
                    <span className="text-white font-bold">{val}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Advantages & Disadvantages */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 space-y-2">
                <h4 className="font-tech text-xs font-semibold text-emerald-400 uppercase flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4" /> Advantages
                </h4>
                <ul className="space-y-1 text-xs text-slate-300">
                  {activeDatasheet.advantages.map((adv, idx) => (
                    <li key={idx}>• {adv}</li>
                  ))}
                </ul>
              </div>

              <div className="p-4 rounded-2xl bg-red-950/20 border border-red-500/30 space-y-2">
                <h4 className="font-tech text-xs font-semibold text-red-400 flex items-center gap-1.5">
                  <XCircle className="w-4 h-4" /> Disadvantages & Mitigation
                </h4>
                <ul className="space-y-1 text-xs text-slate-300">
                  {activeDatasheet.disadvantages.map((dis, idx) => (
                    <li key={idx}>• {dis}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-4 flex justify-end">
              <button
                onClick={() => setActiveDatasheet(null)}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-black font-tech font-bold text-xs"
              >
                CLOSE DATASHEET
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

import React, { useState } from 'react';
import { ARCHITECTURE_NODES } from '../data/projectData';
import { ArchitectureNode } from '../types';
import { 
  Layers, 
  X, 
  Zap, 
  ShieldCheck, 
  Activity, 
  Calculator, 
  CheckCircle2, 
  AlertTriangle,
  ArrowRight
} from 'lucide-react';

export const SystemArchitectureModal: React.FC = () => {
  const [selectedNode, setSelectedNode] = useState<ArchitectureNode | null>(ARCHITECTURE_NODES[0]);

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
      {/* Title */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
          <Layers className="w-4 h-4" />
          <span>SYSTEM TOPOLOGY & BLOCK SCHEMATIC</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-tech text-white">
          SYSTEM <span className="text-cyan-400">ARCHITECTURE</span>
        </h2>
        <p className="text-slate-300 max-w-2xl mx-auto text-sm sm:text-base">
          Interactive microgrid schematic. Select any subsystem node to inspect mathematical models, protective relay schemes, and electrical tolerances.
        </p>
      </div>

      {/* Block Diagram Cards Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {ARCHITECTURE_NODES.map((node) => {
          const isSelected = selectedNode?.id === node.id;
          return (
            <div
              key={node.id}
              onClick={() => setSelectedNode(node)}
              className={`p-6 rounded-3xl cursor-pointer transition-all duration-300 glass-panel glass-panel-hover flex flex-col justify-between ${
                isSelected
                  ? 'border-cyan-400 bg-cyan-950/60 shadow-2xl shadow-cyan-500/30 scale-105'
                  : ''
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800">
                    {node.category}
                  </span>
                  <Zap className={`w-4 h-4 ${isSelected ? 'text-cyan-400 animate-bounce' : 'text-slate-500'}`} />
                </div>
                <h3 className="font-tech text-lg font-bold text-white">{node.title}</h3>
                <p className="text-xs text-slate-300 leading-relaxed">{node.subtitle}</p>
              </div>

              <div className="pt-6 border-t border-slate-800 space-y-2 font-mono text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>VOLTAGE:</span>
                  <span className="text-white font-bold">{node.voltage}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>EFFICIENCY:</span>
                  <span className="text-emerald-400 font-bold">{node.efficiency}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Node Details Panel */}
      {selectedNode && (
        <div className="glass-panel p-6 sm:p-8 rounded-3xl border-cyan-500/40 bg-gradient-to-b from-slate-900 to-slate-950 space-y-8 animate-fadeIn">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-cyan-500/20 pb-6">
            <div>
              <span className="text-xs font-mono text-cyan-400 font-bold uppercase tracking-wider">
                SUBSYSTEM INSPECTION • {selectedNode.category}
              </span>
              <h3 className="font-tech text-2xl sm:text-3xl font-bold text-white mt-1">
                {selectedNode.title}
              </h3>
            </div>
            <div className="flex items-center gap-3 font-mono text-xs">
              <span className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-cyan-300">
                VOLTAGE: <strong className="text-white">{selectedNode.voltage}</strong>
              </span>
              <span className="px-3 py-1.5 rounded-xl bg-emerald-950 border border-emerald-500/40 text-emerald-400">
                EFFICIENCY: <strong className="text-emerald-300">{selectedNode.efficiency}</strong>
              </span>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Left: Working Principle & Specs */}
            <div className="space-y-6">
              <div>
                <h4 className="font-tech text-sm font-semibold text-cyan-400 uppercase tracking-wider mb-2 flex items-center gap-2">
                  <Activity className="w-4 h-4" /> Working Principle
                </h4>
                <p className="text-sm text-slate-300 leading-relaxed font-sans">{selectedNode.workingPrinciple}</p>
              </div>

              <div>
                <h4 className="font-tech text-sm font-semibold text-cyan-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" /> Key Technical Specifications
                </h4>
                <ul className="space-y-2">
                  {selectedNode.specifications.map((spec, idx) => (
                    <li key={idx} className="text-xs text-slate-300 flex items-center gap-2.5 font-mono bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                      <ArrowRight className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span>{spec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Right: Protections, Math & Advantages */}
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30 space-y-2">
                <h4 className="font-tech text-xs font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4" /> Protective Relay & Safety Logic
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed font-sans">{selectedNode.protection}</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-cyan-500/30 space-y-2">
                <h4 className="font-tech text-xs font-semibold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                  <Calculator className="w-4 h-4" /> Governing Mathematical Formula
                </h4>
                <div className="p-3 rounded-xl bg-slate-950 font-mono text-cyan-300 text-sm overflow-x-auto border border-slate-800">
                  {selectedNode.mathFormula}
                </div>
              </div>

              <div>
                <h4 className="font-tech text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-2">Advantages</h4>
                <ul className="space-y-1.5">
                  {selectedNode.advantages.map((adv, idx) => (
                    <li key={idx} className="text-xs text-slate-300 flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>{adv}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

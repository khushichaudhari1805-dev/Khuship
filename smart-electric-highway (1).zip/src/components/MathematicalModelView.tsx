import React, { useState } from 'react';
import { MATH_FORMULAS } from '../data/projectData';
import { Calculator, CheckCircle2, Zap, Sliders } from 'lucide-react';

export const MathematicalModelView: React.FC = () => {
  const [calcVoltage, setCalcVoltage] = useState<number>(750);
  const [calcCurrent, setCalcCurrent] = useState<number>(200);

  const calculatedPowerKw = (calcVoltage * calcCurrent) / 1000;

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
      {/* Title */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
          <Calculator className="w-4 h-4" />
          <span>GOVERNING ENGINEERING EQUATIONS</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-tech text-white">
          MATHEMATICAL <span className="text-cyan-400">MODEL</span>
        </h2>
        <p className="text-slate-300 max-w-2xl mx-auto text-sm sm:text-base">
          Formal electrical physics equations governing catenary line power transfer, converter duty cycles, and battery state of charge.
        </p>
      </div>

      {/* Interactive Quick Power Calculator */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border-cyan-500/40 bg-gradient-to-r from-slate-950 via-cyan-950/20 to-slate-950 space-y-6">
        <div className="flex items-center justify-between border-b border-cyan-500/20 pb-4">
          <h3 className="font-tech text-lg font-bold text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-cyan-400" />
            <span>INTERACTIVE CATENARY POWER CALCULATOR (P = V × I)</span>
          </h3>
          <span className="text-xs font-mono text-cyan-400 font-bold">750V DC NOMINAL</span>
        </div>

        <div className="grid sm:grid-cols-3 gap-6 items-center">
          <div className="space-y-2">
            <label className="text-xs font-mono text-slate-300">CATENARY VOLTAGE (V):</label>
            <input
              type="number"
              value={calcVoltage}
              onChange={(e) => setCalcVoltage(Number(e.target.value))}
              className="w-full bg-slate-900 border border-cyan-500/40 rounded-xl px-4 py-2 text-sm font-mono text-cyan-300 font-bold focus:outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-mono text-slate-300">LOAD CURRENT (I):</label>
            <input
              type="number"
              value={calcCurrent}
              onChange={(e) => setCalcCurrent(Number(e.target.value))}
              className="w-full bg-slate-900 border border-cyan-500/40 rounded-xl px-4 py-2 text-sm font-mono text-cyan-300 font-bold focus:outline-none"
            />
          </div>

          <div className="p-4 rounded-2xl bg-slate-900 border border-emerald-500/40 text-center space-y-1">
            <span className="text-[10px] font-mono text-slate-400 uppercase">DELIVERED POWER</span>
            <div className="font-tech text-3xl font-bold text-emerald-400">{calculatedPowerKw} kW</div>
          </div>
        </div>
      </div>

      {/* Math Formula Cards */}
      <div className="grid md:grid-cols-2 gap-6">
        {MATH_FORMULAS.map((f) => (
          <div key={f.id} className="glass-panel p-6 rounded-3xl space-y-4 border-cyan-500/20 glass-panel-hover flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-cyan-400 text-[10px] font-mono font-bold uppercase">
                  {f.category}
                </span>
                <Calculator className="w-4 h-4 text-slate-500" />
              </div>
              <h3 className="font-tech text-lg font-bold text-white">{f.title}</h3>
              <p className="text-xs text-slate-300 leading-relaxed font-sans">{f.description}</p>
            </div>

            {/* Formula Block */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-500/30 text-cyan-300 font-mono text-sm text-center shadow-inner overflow-x-auto">
              {f.latex}
            </div>

            {/* Variable Definitions */}
            <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1.5 font-mono text-[11px]">
              {f.variables.map((v, idx) => (
                <div key={idx} className="flex justify-between text-slate-400">
                  <span>{v.symbol} ({v.name}):</span>
                  <span className="text-slate-200">{v.unit}</span>
                </div>
              ))}
            </div>

            {/* Worked Example */}
            <div className="text-[11px] font-mono text-emerald-400 bg-emerald-950/20 p-3 rounded-xl border border-emerald-500/30">
              💡 <strong>Example:</strong> {f.example}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

import React, { useState, useEffect } from 'react';
import { TelemetryData } from '../types';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  BarChart, 
  Bar 
} from 'recharts';
import { 
  Activity, 
  Zap, 
  Sun, 
  Battery, 
  ShieldCheck, 
  Gauge, 
  Thermometer, 
  Leaf, 
  RefreshCw, 
  AlertCircle 
} from 'lucide-react';

export const LiveDashboard: React.FC = () => {
  const [telemetryHistory, setTelemetryHistory] = useState<TelemetryData[]>([]);
  const [currentData, setCurrentData] = useState<TelemetryData>({
    timestamp: new Date().toLocaleTimeString(),
    solarVoltage: 684.2,
    solarCurrent: 42.8,
    solarPower: 29.2,
    batteryVoltage: 642.5,
    batteryCurrent: 12.4,
    batterySOC: 84.5,
    batterySOH: 98.2,
    supercapVoltage: 748.0,
    gridStatus: 'Standby',
    relayStatus: 'Solar Dominant',
    motorSpeedRPM: 2850,
    motorTempC: 48.5,
    energyGeneratedkWh: 482.6,
    carbonSavedKg: 386.1,
    powerDemandkW: 185.0,
  });

  // Simulated telemetry stream updating every 2 seconds
  useEffect(() => {
    // Generate initial history
    const initial: TelemetryData[] = [];
    const now = new Date();
    for (let i = 10; i >= 0; i--) {
      const time = new Date(now.getTime() - i * 5000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      initial.push({
        timestamp: time,
        solarVoltage: Math.round((680 + Math.random() * 20) * 10) / 10,
        solarCurrent: Math.round((40 + Math.random() * 8) * 10) / 10,
        solarPower: Math.round((28 + Math.random() * 5) * 10) / 10,
        batteryVoltage: 642.0,
        batteryCurrent: Math.round((10 + Math.random() * 10) * 10) / 10,
        batterySOC: Math.round((84 + Math.random() * 0.5) * 10) / 10,
        batterySOH: 98.2,
        supercapVoltage: Math.round((745 + Math.random() * 5) * 10) / 10,
        gridStatus: 'Standby',
        relayStatus: 'Solar Dominant',
        motorSpeedRPM: Math.round(2800 + Math.random() * 200),
        motorTempC: Math.round((48 + Math.random() * 2) * 10) / 10,
        energyGeneratedkWh: Math.round((480 + (10 - i) * 1.2) * 10) / 10,
        carbonSavedKg: Math.round((380 + (10 - i) * 0.9) * 10) / 10,
        powerDemandkW: Math.round(180 + Math.random() * 20),
      });
    }
    setTelemetryHistory(initial);

    const interval = setInterval(() => {
      const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      const newPoint: TelemetryData = {
        timestamp: timeStr,
        solarVoltage: Math.round((680 + Math.random() * 20) * 10) / 10,
        solarCurrent: Math.round((40 + Math.random() * 8) * 10) / 10,
        solarPower: Math.round((28 + Math.random() * 5) * 10) / 10,
        batteryVoltage: 642.0,
        batteryCurrent: Math.round((10 + Math.random() * 10) * 10) / 10,
        batterySOC: Math.round((84.5 + (Math.random() * 0.2 - 0.1)) * 10) / 10,
        batterySOH: 98.2,
        supercapVoltage: Math.round((745 + Math.random() * 5) * 10) / 10,
        gridStatus: 'Standby',
        relayStatus: 'Solar Dominant',
        motorSpeedRPM: Math.round(2800 + Math.random() * 200),
        motorTempC: Math.round((48 + Math.random() * 2) * 10) / 10,
        energyGeneratedkWh: Math.round((482.6 + Math.random() * 0.5) * 10) / 10,
        carbonSavedKg: Math.round((386.1 + Math.random() * 0.4) * 10) / 10,
        powerDemandkW: Math.round(180 + Math.random() * 20),
      };

      setCurrentData(newPoint);
      setTelemetryHistory((prev) => [...prev.slice(1), newPoint]);
    }, 2500);

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
      {/* Title */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
          <Activity className="w-4 h-4 animate-pulse" />
          <span>IOT ESP32 TELEMETRY STREAM</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-tech text-white">
          LIVE TELEMETRY <span className="text-cyan-400">DASHBOARD</span>
        </h2>
        <p className="text-slate-300 max-w-2xl mx-auto text-sm sm:text-base">
          Real-time sensor data polled directly from roadside microgrid sensors and catenary bus pantograph CAN-Bus.
        </p>
      </div>

      {/* Telemetry Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        {/* Solar Voltage */}
        <div className="glass-panel p-4 rounded-2xl border-amber-500/30 space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono">
            <span>SOLAR VOLTAGE</span>
            <Sun className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline gap-1 font-tech text-2xl font-bold text-white">
            <span>{currentData.solarVoltage}</span>
            <span className="text-xs text-amber-400">V</span>
          </div>
          <p className="text-[10px] font-mono text-emerald-400">Current: {currentData.solarCurrent} A</p>
        </div>

        {/* Solar Power */}
        <div className="glass-panel p-4 rounded-2xl border-amber-500/30 space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono">
            <span>SOLAR POWER</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline gap-1 font-tech text-2xl font-bold text-white">
            <span>{currentData.solarPower}</span>
            <span className="text-xs text-amber-400">kW</span>
          </div>
          <p className="text-[10px] font-mono text-cyan-300">MPPT Efficiency: 99.8%</p>
        </div>

        {/* Battery SOC */}
        <div className="glass-panel p-4 rounded-2xl border-emerald-500/30 space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono">
            <span>BATTERY SOC</span>
            <Battery className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-1 font-tech text-2xl font-bold text-white">
            <span>{currentData.batterySOC}</span>
            <span className="text-xs text-emerald-400">%</span>
          </div>
          <p className="text-[10px] font-mono text-slate-400">SOH: {currentData.batterySOH}%</p>
        </div>

        {/* Supercap Voltage */}
        <div className="glass-panel p-4 rounded-2xl border-purple-500/30 space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono">
            <span>SUPERCAP VOLTAGE</span>
            <ShieldCheck className="w-4 h-4 text-purple-400" />
          </div>
          <div className="flex items-baseline gap-1 font-tech text-2xl font-bold text-white">
            <span>{currentData.supercapVoltage}</span>
            <span className="text-xs text-purple-400">V</span>
          </div>
          <p className="text-[10px] font-mono text-emerald-400">Burst Ready (165F)</p>
        </div>

        {/* Motor Speed */}
        <div className="glass-panel p-4 rounded-2xl border-cyan-500/30 space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-mono">
            <span>BLDC MOTOR SPEED</span>
            <Gauge className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex items-baseline gap-1 font-tech text-2xl font-bold text-white">
            <span>{currentData.motorSpeedRPM}</span>
            <span className="text-xs text-cyan-400">RPM</span>
          </div>
          <p className="text-[10px] font-mono text-slate-400">Temp: {currentData.motorTempC} °C</p>
        </div>
      </div>

      {/* Recharts Telemetry Trends */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Power Demand vs Generation Graph */}
        <div className="glass-panel p-6 rounded-3xl space-y-4 border-cyan-500/30">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-tech text-base font-bold text-white">CATENARY POWER DEMAND vs SOLAR GENERATION (kW)</h3>
            <span className="text-xs font-mono text-cyan-400">REAL-TIME STREAM</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={telemetryHistory}>
                <defs>
                  <linearGradient id="colorPower" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorSolar" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="timestamp" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#06b6d4', borderRadius: '12px' }} />
                <Area type="monotone" dataKey="powerDemandkW" stroke="#06b6d4" fillOpacity={1} fill="url(#colorPower)" name="Bus Power Demand (kW)" />
                <Area type="monotone" dataKey="solarPower" stroke="#f59e0b" fillOpacity={1} fill="url(#colorSolar)" name="Solar Generated (kW)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Cumulative Energy Generated & Carbon Offset */}
        <div className="glass-panel p-6 rounded-3xl space-y-4 border-emerald-500/30">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-tech text-base font-bold text-white">RENEWABLE GENERATION & CO₂ OFFSET (TODAY)</h3>
            <span className="text-xs font-mono text-emerald-400">NET ZERO STATS</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={telemetryHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="timestamp" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#10b981', borderRadius: '12px' }} />
                <Bar dataKey="energyGeneratedkWh" fill="#10b981" name="Energy Generated (kWh)" radius={[6, 6, 0, 0]} />
                <Bar dataKey="carbonSavedKg" fill="#38bdf8" name="CO₂ Offset (kg)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </section>
  );
};

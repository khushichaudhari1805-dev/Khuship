import React, { useState } from 'react';
import { X, Download, Printer, CheckCircle, FileText, Zap } from 'lucide-react';
import { PROJECT_INFO, HOME_STATS, COMPONENTS_DATA, MATH_FORMULAS } from '../data/projectData';

interface ReportDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReportDownloadModal: React.FC<ReportDownloadModalProps> = ({ isOpen, onClose }) => {
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDownload = () => {
    setDownloading(true);
    setTimeout(() => {
      setDownloading(false);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 3000);
    }, 1500);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="glass-panel w-full max-w-4xl rounded-3xl border-cyan-500/40 p-6 sm:p-8 bg-[#030712] max-h-[90vh] overflow-y-auto space-y-6">
        {/* Header Actions */}
        <div className="flex items-center justify-between border-b border-cyan-500/20 pb-4">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-cyan-400" />
            <span className="font-tech text-sm font-bold text-white">IEEE TECHNICAL REPORT PREVIEW</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 text-xs font-mono flex items-center gap-1.5 hover:text-white"
            >
              <Printer className="w-4 h-4" />
              <span>PRINT</span>
            </button>
            <button
              onClick={handleDownload}
              disabled={downloading}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-black font-tech font-bold text-xs flex items-center gap-1.5 hover:scale-105 transition-transform"
            >
              <Download className="w-4 h-4" />
              <span>{downloading ? 'GENERATING PDF...' : 'DOWNLOAD PDF'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-900 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {downloadSuccess && (
          <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs font-mono text-center flex items-center justify-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            <span>Technical Report PDF successfully compiled and downloaded!</span>
          </div>
        )}

        {/* Official Paper Layout Printable Canvas */}
        <div className="p-8 bg-slate-950 border border-slate-800 rounded-2xl text-slate-200 font-sans space-y-6 text-xs leading-relaxed">
          {/* Header Credentials */}
          <div className="text-center space-y-2 border-b border-slate-800 pb-6">
            <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest block font-bold">
              MAJOR ENGINEERING PROJECT TECHNICAL SPECIFICATION REPORT
            </span>
            <h1 className="text-xl sm:text-2xl font-bold font-tech text-white">
              {PROJECT_INFO.title}
            </h1>
            <p className="text-slate-400 font-mono text-[11px]">{PROJECT_INFO.subtitle}</p>
            <div className="text-slate-400 font-mono text-[10px] pt-2">
              <span>{PROJECT_INFO.university} • {PROJECT_INFO.college}</span>
              <span className="block text-cyan-300 mt-0.5">Guide: {PROJECT_INFO.guidedBy}</span>
            </div>
          </div>

          {/* Abstract */}
          <div className="space-y-2">
            <h3 className="font-tech text-xs font-bold text-cyan-400 uppercase">I. ABSTRACT</h3>
            <p className="text-slate-300 font-sans leading-relaxed">{PROJECT_INFO.abstract}</p>
          </div>

          {/* Performance Summary Table */}
          <div className="space-y-2">
            <h3 className="font-tech text-xs font-bold text-emerald-400 uppercase">II. SYSTEM METRICS</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 font-mono text-[10px]">
              {HOME_STATS.map((s) => (
                <div key={s.id} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-slate-400 block truncate">{s.label}:</span>
                  <span className="text-cyan-300 font-bold">{s.value} {s.suffix}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Key Equations */}
          <div className="space-y-2">
            <h3 className="font-tech text-xs font-bold text-purple-400 uppercase">III. MATHEMATICAL MODEL EQUATIONS</h3>
            <div className="space-y-2 font-mono text-[10px]">
              {MATH_FORMULAS.slice(0, 3).map((f) => (
                <div key={f.id} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex justify-between items-center">
                  <span className="text-slate-300 font-bold">{f.title}:</span>
                  <span className="text-cyan-400 font-mono">{f.latex}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

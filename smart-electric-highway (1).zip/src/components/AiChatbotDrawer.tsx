import React, { useState, useRef, useEffect } from 'react';
import { Bot, X, Send, Sparkles, User, Zap } from 'lucide-react';

interface Message {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  time: string;
}

interface AiChatbotDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AiChatbotDrawer: React.FC<AiChatbotDrawerProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'bot',
      text: 'Hello! I am VoltAI, the Smart Electric Highway knowledge assistant. Ask me anything about our 750V DC catenary line, hybrid supercapacitor storage, or ESP32 switching logic!',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!isOpen) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: inputText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    const query = inputText.toLowerCase();
    setInputText('');
    setIsTyping(true);

    setTimeout(() => {
      let response = "That's a great engineering query! Our system uses a 750V DC catenary line paired with a 200 kWh LiFePO4 battery and 165F supercapacitor bank managed by an ESP32 dual-core microcontroller.";

      if (query.includes('voltage') || query.includes('catenary')) {
        response = "The overhead catenary line operates at a regulated 750V DC rail voltage, constructed from a CuAg 0.1% copper-silver alloy supporting continuous current up to 800 Amperes.";
      } else if (query.includes('supercapacitor') || query.includes('battery')) {
        response = "The Hybrid Energy Storage System (HESS) pairs a 200 kWh LiFePO4 battery with a 165 Farad 750V Graphene Supercapacitor bank. The supercapacitor absorbs high-frequency acceleration current spikes, extending battery lifespan by 3x.";
      } else if (query.includes('solar') || query.includes('efficiency')) {
        response = "Roadside bi-facial monocrystalline solar panels deliver 23.8% efficiency. Dual-sided absorption captures ground albedo reflection along highway shoulders for up to +25% extra daytime power.";
      } else if (query.includes('cost') || query.includes('roi') || query.includes('payback')) {
        response = "Capital expenditure for a 25 km corridor is approximately $3.3M, yielding over $800,000/yr in operational fuel savings vs diesel fleets, achieving a payback period of ~3.8 years.";
      } else if (query.includes('esp32') || query.includes('switching') || query.includes('relay')) {
        response = "The ESP32 microcontroller executes sub-millisecond opto-isolated solid-state relay switching across 4 priority sources: Solar PV -> Battery Storage -> Utility Grid Substation -> Supercapacitor Peak Boost.";
      }

      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'bot',
        text: response,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);
    }, 1200);
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[420px] bg-[#030712]/95 backdrop-blur-2xl border-l border-cyan-500/30 shadow-2xl flex flex-col animate-slideLeft">
      {/* Header */}
      <div className="p-4 border-b border-cyan-500/20 flex items-center justify-between bg-slate-900/60">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500 to-emerald-500 p-0.5 flex items-center justify-center">
            <div className="w-full h-full bg-black rounded-[10px] flex items-center justify-center">
              <Bot className="w-5 h-5 text-cyan-400 animate-pulse" />
            </div>
          </div>
          <div>
            <h3 className="font-tech text-sm font-bold text-white flex items-center gap-1.5">
              VoltAI ASSISTANT
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            </h3>
            <span className="text-[10px] font-mono text-emerald-400">Engineering Knowledge Agent</span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Messages Stream */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div className={`p-3.5 rounded-2xl max-w-[85%] text-xs font-sans leading-relaxed shadow-md ${
              m.sender === 'user'
                ? 'bg-gradient-to-r from-cyan-500 to-emerald-500 text-black font-semibold rounded-br-none'
                : 'bg-slate-900 border border-cyan-500/30 text-slate-200 rounded-bl-none'
            }`}>
              {m.text}
            </div>
            <span className="text-[9px] font-mono text-slate-500 mt-1 px-1">{m.time}</span>
          </div>
        ))}

        {isTyping && (
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 bg-slate-900/80 p-3 rounded-2xl border border-slate-800 w-fit">
            <Sparkles className="w-4 h-4 animate-spin" />
            <span>VoltAI is formulating response...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Box */}
      <form onSubmit={handleSend} className="p-3 border-t border-slate-800 bg-slate-900/80 flex items-center gap-2">
        <input
          type="text"
          placeholder="Ask VoltAI about voltage, supercap, solar..."
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
        />
        <button
          type="submit"
          className="p-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-black font-bold hover:scale-105 transition-transform"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};

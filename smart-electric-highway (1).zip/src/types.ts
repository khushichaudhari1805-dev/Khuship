export type NavTab = 
  | 'home'
  | 'about'
  | 'how-it-works'
  | 'architecture'
  | 'components'
  | 'ems'
  | 'dashboard'
  | '3d-simulation'
  | 'ai-energy'
  | 'math-model'
  | 'research'
  | 'cost-analysis'
  | 'future-scope'
  | 'contact';

export interface StatItem {
  id: string;
  label: string;
  value: number;
  suffix: string;
  prefix?: string;
  change: string;
  isPositive: boolean;
  description: string;
}

export interface ComponentSpec {
  id: string;
  name: string;
  category: 'Power' | 'Control' | 'Mechanical' | 'Storage' | 'Grid';
  image: string;
  specs: Record<string, string>;
  workingPrinciple: string;
  advantages: string[];
  disadvantages: string[];
  cost: string;
  lifespan: string;
  voltage?: string;
  current?: string;
  efficiency?: string;
  datasheetUrl?: string;
}

export interface ArchitectureNode {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  voltage: string;
  current: string;
  efficiency: string;
  losses: string;
  workingPrinciple: string;
  specifications: string[];
  advantages: string[];
  protection: string;
  mathFormula: string;
  applications: string[];
}

export interface ResearchPaper {
  id: string;
  title: string;
  authors: string[];
  journal: string;
  year: number;
  doi: string;
  summary: string;
  keyFindings: string[];
  citations: number;
  downloadUrl?: string;
}

export interface MathFormula {
  id: string;
  title: string;
  latex: string;
  description: string;
  variables: { name: string; symbol: string; unit: string; description: string }[];
  example: string;
  category: 'Electrical' | 'Efficiency' | 'Battery' | 'Control' | 'Thermal';
}

export interface TelemetryData {
  timestamp: string;
  solarVoltage: number;
  solarCurrent: number;
  solarPower: number;
  batteryVoltage: number;
  batteryCurrent: number;
  batterySOC: number;
  batterySOH: number;
  supercapVoltage: number;
  gridStatus: 'Active' | 'Standby' | 'Fault';
  relayStatus: 'Solar Dominant' | 'Battery Auxiliary' | 'Grid Fallback' | 'Supercap Boost';
  motorSpeedRPM: number;
  motorTempC: number;
  energyGeneratedkWh: number;
  carbonSavedKg: number;
  powerDemandkW: number;
}

export interface TeamMember {
  name: string;
  role: string;
  studentId?: string;
  department: string;
  email: string;
  github?: string;
  linkedin?: string;
  image: string;
  bio: string;
}

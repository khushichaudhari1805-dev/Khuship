import React, { useState } from 'react';
import { NavTab } from '../types';
import { 
  Zap, 
  Search, 
  Bot, 
  FileText, 
  Menu, 
  X, 
  Cpu, 
  Activity, 
  Box, 
  Calculator, 
  BookOpen, 
  DollarSign, 
  Layers, 
  Phone,
  Sparkles,
  Volume2,
  VolumeX
} from 'lucide-react';

interface NavbarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  onOpenSearch: () => void;
  onOpenChat: () => void;
  onOpenReportModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenSearch,
  onOpenChat,
  onOpenReportModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [voiceActive, setVoiceActive] = useState(false);

  const toggleVoice = () => {
    setVoiceActive(!voiceActive);
    if (!voiceActive) {
      const speech = new SpeechSynthesisUtterance(
        "Welcome to Smart Electric Highway using Overhead Line and Hybrid Energy Storage system."
      );
      speech.rate = 1.0;
      speech.pitch = 1.0;
      window.speechSynthesis.speak(speech);
    } else {
      window.speechSynthesis.cancel();
    }
  };

  const navItems: { id: NavTab; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: 'Home', icon: <Zap className="w-4 h-4" /> },
    { id: 'about', label: 'About', icon: <Cpu className="w-4 h-4" /> },
    { id: 'how-it-works', label: 'How It Works', icon: <Activity className="w-4 h-4" /> },
    { id: 'architecture', label: 'Architecture', icon: <Layers className="w-4 h-4" /> },
    { id: 'components', label: 'Components', icon: <Box className="w-4 h-4" /> },
    { id: 'ems', label: 'Energy EMS', icon: <Zap className="w-4 h-4" /> },
    { id: 'dashboard', label: 'Dashboard', icon: <Activity className="w-4 h-4" /> },
    { id: '3d-simulation', label: '3D Simulation', icon: <Box className="w-4 h-4" /> },
    { id: 'ai-energy', label: 'AI Energy', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'math-model', label: 'Math Model', icon: <Calculator className="w-4 h-4" /> },
    { id: 'research', label: 'Research', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'cost-analysis', label: 'Cost & ROI', icon: <DollarSign className="w-4 h-4" /> },
    { id: 'future-scope', label: 'Future Scope', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'contact', label: 'Contact', icon: <Phone className="w-4 h-4" /> },
  ];

  const handleSelectTab = (tab: NavTab) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-cyan-500/20 bg-[#030712]/80 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo & Title */}
          <div 
            onClick={() => handleSelectTab('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-emerald-500 p-0.5 shadow-lg shadow-cyan-500/20 group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-[#030712] rounded-[10px] flex items-center justify-center">
                <Zap className="w-5 h-5 text-cyan-400 group-hover:text-emerald-400 transition-colors animate-pulse" />
              </div>
            </div>
            <div>
              <span className="font-tech text-base sm:text-lg font-bold tracking-wider text-white flex items-center gap-1.5">
                SMART <span className="text-cyan-400">HIGHWAY</span>
              </span>
              <span className="hidden sm:block text-[10px] font-mono text-emerald-400 tracking-widest uppercase">
                750V DC • Hybrid Storage • AI Microgrid
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links (Primary tabs) */}
          <nav className="hidden lg:flex items-center gap-1 bg-slate-900/60 p-1.5 rounded-full border border-cyan-500/15">
            {navItems.slice(0, 8).map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleSelectTab(item.id)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 flex items-center gap-1.5 whitespace-nowrap ${
                    isActive
                      ? 'bg-gradient-to-r from-cyan-500 to-emerald-500 text-black font-semibold shadow-md shadow-cyan-500/20'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  {item.icon}
                  {item.label}
                </button>
              );
            })}

            {/* Dropdown for More */}
            <div className="relative group">
              <button className="px-3 py-1.5 rounded-full text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800/60 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                More
              </button>
              <div className="absolute right-0 top-full mt-2 w-48 bg-slate-900/95 border border-cyan-500/20 rounded-2xl shadow-2xl p-2 hidden group-hover:block backdrop-blur-xl z-50">
                {navItems.slice(8).map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleSelectTab(item.id)}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium flex items-center gap-2 transition-colors ${
                      activeTab === item.id
                        ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                        : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    {item.icon}
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </nav>

          {/* Quick Action Tools */}
          <div className="flex items-center gap-2">
            {/* Search Button */}
            <button
              onClick={onOpenSearch}
              title="Search documentation & components"
              className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700/60 text-slate-300 hover:text-cyan-400 transition-colors"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* AI Assistant Button */}
            <button
              onClick={onOpenChat}
              title="Ask VoltAI Assistant"
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-950 to-emerald-950 border border-cyan-500/40 text-cyan-300 hover:text-white hover:border-cyan-400 transition-all text-xs font-mono"
            >
              <Bot className="w-4 h-4 text-cyan-400 animate-pulse" />
              <span>VoltAI</span>
            </button>

            {/* Voice Narrator Switch */}
            <button
              onClick={toggleVoice}
              title={voiceActive ? 'Disable Voice Assistant' : 'Enable Voice Overview'}
              className={`p-2 rounded-xl border transition-colors ${
                voiceActive
                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
                  : 'bg-slate-900/80 border-slate-700/60 text-slate-300 hover:text-white'
              }`}
            >
              {voiceActive ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* PDF Report Download Button */}
            <button
              onClick={onOpenReportModal}
              title="Download IEEE Technical Report PDF"
              className="hidden md:flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-400 text-xs font-semibold transition-all hover:shadow-lg hover:shadow-cyan-500/10"
            >
              <FileText className="w-4 h-4" />
              <span>Report</span>
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-cyan-500/20 bg-[#030712]/95 backdrop-blur-2xl p-4 space-y-2 max-h-[80vh] overflow-y-auto">
          <div className="grid grid-cols-2 gap-2 pb-3">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleSelectTab(item.id)}
                className={`p-2.5 rounded-xl text-xs font-medium flex items-center gap-2 transition-all ${
                  activeTab === item.id
                    ? 'bg-gradient-to-r from-cyan-500 to-emerald-500 text-black font-semibold'
                    : 'bg-slate-900/80 text-slate-300 border border-slate-800'
                }`}
              >
                {item.icon}
                <span className="truncate">{item.label}</span>
              </button>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenChat();
              }}
              className="flex-1 py-2 rounded-xl bg-cyan-950 border border-cyan-500/40 text-cyan-300 text-xs font-mono flex items-center justify-center gap-2"
            >
              <Bot className="w-4 h-4 text-cyan-400" />
              <span>VoltAI Chatbot</span>
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenReportModal();
              }}
              className="flex-1 py-2 rounded-xl bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-xs font-mono flex items-center justify-center gap-2"
            >
              <FileText className="w-4 h-4 text-emerald-400" />
              <span>PDF Report</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

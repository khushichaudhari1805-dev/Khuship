import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Play, Pause, Sun, Moon, Zap, RotateCcw, Camera, Sliders } from 'lucide-react';

export const HighwaySimulation3D: React.FC = () => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [speedMultiplier, setSpeedMultiplier] = useState(1);
  const [isNightMode, setIsNightMode] = useState(true);
  const [isPowerActive, setIsPowerActive] = useState(true);
  const [cameraView, setCameraView] = useState<'orbit' | 'chase' | 'overhead' | 'contact'>('orbit');
  const [busPositionX, setBusPositionX] = useState(0);

  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const busMeshRef = useRef<THREE.Group | null>(null);
  const pantographRef = useRef<THREE.Group | null>(null);
  const windTurbineBladesRef = useRef<THREE.Mesh[]>([]);
  const sparkParticlesRef = useRef<THREE.Points | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(isNightMode ? 0x030712 : 0x87ceeb);
    scene.fog = new THREE.FogExp2(isNightMode ? 0x030712 : 0xe2e8f0, 0.015);

    // Camera
    const camera = new THREE.PerspectiveCamera(
      60,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    cameraRef.current = camera;
    camera.position.set(20, 15, 30);
    camera.lookAt(0, 4, 0);

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    rendererRef.current = renderer;
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(isNightMode ? 0x1e293b : 0xffffff, isNightMode ? 0.6 : 1.2);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, isNightMode ? 0.8 : 1.5);
    dirLight.position.set(50, 80, 30);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    scene.add(dirLight);

    // Neon Cyan / Green Ambient Lights for Highway
    const cyanLight = new THREE.PointLight(0x06b6d4, 3, 40);
    cyanLight.position.set(0, 10, 0);
    scene.add(cyanLight);

    // --- 1. ROAD & HIGHWAY ---
    const roadWidth = 16;
    const roadLength = 200;
    const roadGeo = new THREE.PlaneGeometry(roadLength, roadWidth);
    const roadMat = new THREE.MeshStandardMaterial({
      color: 0x111827,
      roughness: 0.8,
      metalness: 0.2,
    });
    const road = new THREE.Mesh(roadGeo, roadMat);
    road.rotation.x = -Math.PI / 2;
    road.receiveShadow = true;
    scene.add(road);

    // Lane Markings
    const laneMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    for (let x = -90; x <= 90; x += 10) {
      const laneGeo = new THREE.PlaneGeometry(4, 0.4);
      const laneMesh = new THREE.Mesh(laneGeo, laneMat);
      laneMesh.rotation.x = -Math.PI / 2;
      laneMesh.position.set(x, 0.02, 0);
      scene.add(laneMesh);
    }

    // --- 2. OVERHEAD CATENARY POLES & WIRES ---
    const poleGeo = new THREE.CylinderGeometry(0.2, 0.3, 10, 16);
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8 });
    const armMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.9 });

    for (let x = -90; x <= 90; x += 30) {
      // Support pole
      const pole = new THREE.Mesh(poleGeo, poleMat);
      pole.position.set(x, 5, -6);
      pole.castShadow = true;
      scene.add(pole);

      // Horizontal arm extension
      const armGeo = new THREE.BoxGeometry(0.3, 0.3, 8);
      const arm = new THREE.Mesh(armGeo, armMat);
      arm.position.set(x, 9.5, -2);
      scene.add(arm);
    }

    // Catenary Wires (Copper / Cyan Glowing Wires)
    const wireMat = new THREE.MeshBasicMaterial({ color: isPowerActive ? 0x00ffff : 0x475569 });
    const wireGeo1 = new THREE.CylinderGeometry(0.06, 0.06, roadLength, 8);
    
    const wire1 = new THREE.Mesh(wireGeo1, wireMat);
    wire1.rotation.z = Math.PI / 2;
    wire1.position.set(0, 9.2, -2);
    scene.add(wire1);

    const wire2 = new THREE.Mesh(wireGeo1, wireMat);
    wire2.rotation.z = Math.PI / 2;
    wire2.position.set(0, 9.2, 2);
    scene.add(wire2);

    // --- 3. ROADSIDE SOLAR FARM ---
    const solarGroup = new THREE.Group();
    const panelGeo = new THREE.BoxGeometry(4, 0.1, 2.5);
    const panelMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.1, metalness: 0.9 });
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x64748b });

    for (let x = -80; x <= 80; x += 15) {
      for (let z = -25; z >= -40; z -= 5) {
        const panel = new THREE.Mesh(panelGeo, panelMat);
        panel.position.set(x, 1.8, z);
        panel.rotation.x = Math.PI / 6; // Angle towards sun
        panel.castShadow = true;
        solarGroup.add(panel);

        const frame = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 2), frameMat);
        frame.position.set(x, 0.8, z);
        solarGroup.add(frame);
      }
    }
    scene.add(solarGroup);

    // --- 4. WIND TURBINES ---
    windTurbineBladesRef.current = [];
    const turbinePositions = [-70, -20, 30, 80];

    turbinePositions.forEach((pos) => {
      // Tower
      const tower = new THREE.Mesh(
        new THREE.CylinderGeometry(0.4, 0.8, 24, 16),
        new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.3 })
      );
      tower.position.set(pos, 12, 30);
      scene.add(tower);

      // Nacelle
      const nacelle = new THREE.Mesh(
        new THREE.BoxGeometry(2, 1.5, 3),
        new THREE.MeshStandardMaterial({ color: 0x94a3b8 })
      );
      nacelle.position.set(pos, 24, 30);
      scene.add(nacelle);

      // Rotor Hub & Blades Group
      const hubGeo = new THREE.ConeGeometry(0.8, 1.2, 16);
      const hub = new THREE.Mesh(hubGeo, new THREE.MeshStandardMaterial({ color: 0x0f172a }));
      hub.rotation.x = Math.PI / 2;
      hub.position.set(pos, 24, 28.5);

      const bladesGroup = new THREE.Group();
      bladesGroup.position.set(pos, 24, 28.2);

      for (let b = 0; b < 3; b++) {
        const bladeGeo = new THREE.BoxGeometry(0.4, 10, 0.1);
        const blade = new THREE.Mesh(bladeGeo, new THREE.MeshStandardMaterial({ color: 0xf8fafc }));
        blade.position.y = 5;
        blade.rotation.z = (b * Math.PI * 2) / 3;
        bladesGroup.add(blade);
      }

      scene.add(hub);
      scene.add(bladesGroup);
      windTurbineBladesRef.current.push(bladesGroup as unknown as THREE.Mesh);
    });

    // --- 5. HEAVY DUTY ELECTRIC BUS WITH PANTOGRAPH ---
    const busGroup = new THREE.Group();
    busMeshRef.current = busGroup;

    // Bus Body (Tesla Cyber-Bus Style)
    const bodyGeo = new THREE.BoxGeometry(14, 3.8, 4.2);
    const bodyMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      metalness: 0.8,
      roughness: 0.2,
    });
    const busBody = new THREE.Mesh(bodyGeo, bodyMat);
    busBody.position.y = 2.8;
    busBody.castShadow = true;
    busGroup.add(busBody);

    // Glowing Neon Side Stripe
    const stripeGeo = new THREE.BoxGeometry(14.1, 0.2, 4.25);
    const stripeMat = new THREE.MeshBasicMaterial({ color: 0x10b981 });
    const stripe = new THREE.Mesh(stripeGeo, stripeMat);
    stripe.position.y = 2.2;
    busGroup.add(stripe);

    // Windshield & Windows
    const windowMat = new THREE.MeshPhysicalMaterial({
      color: 0x06b6d4,
      transmission: 0.6,
      opacity: 0.9,
      transparent: true,
      roughness: 0.1,
    });
    const glass = new THREE.Mesh(new THREE.BoxGeometry(13.8, 1.2, 4.1), windowMat);
    glass.position.y = 3.6;
    busGroup.add(glass);

    // Wheels
    const wheelGeo = new THREE.CylinderGeometry(0.9, 0.9, 0.8, 24);
    const wheelMat = new THREE.MeshStandardMaterial({ color: 0x020617, roughness: 0.9 });

    [
      [-4.5, 0.9, -2],
      [-4.5, 0.9, 2],
      [4.5, 0.9, -2],
      [4.5, 0.9, 2],
    ].forEach(([wx, wy, wz]) => {
      const wheel = new THREE.Mesh(wheelGeo, wheelMat);
      wheel.rotation.x = Math.PI / 2;
      wheel.position.set(wx, wy, wz);
      busGroup.add(wheel);
    });

    // Pantograph Assembly on Bus Roof
    const pantoGroup = new THREE.Group();
    pantographRef.current = pantoGroup;
    pantoGroup.position.set(0, 4.7, -2);

    // Pantograph lower arms
    const pantoMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.9 });
    const arm1 = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 2.8), pantoMat);
    arm1.position.set(-0.8, 1.2, 0);
    arm1.rotation.z = -Math.PI / 4;

    const arm2 = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 2.8), pantoMat);
    arm2.position.set(0.8, 1.2, 0);
    arm2.rotation.z = Math.PI / 4;

    // Contact collector head
    const headGeo = new THREE.BoxGeometry(2.5, 0.15, 0.6);
    const headMat = new THREE.MeshBasicMaterial({ color: isPowerActive ? 0x00ffcc : 0x64748b });
    const pantoHead = new THREE.Mesh(headGeo, headMat);
    pantoHead.position.set(0, 2.4, 0);

    pantoGroup.add(arm1);
    pantoGroup.add(arm2);
    pantoGroup.add(pantoHead);
    busGroup.add(pantoGroup);

    busGroup.position.set(0, 0, -2);
    scene.add(busGroup);

    // --- 6. SPARK PARTICLES AT PANTOGRAPH CONTACT ---
    const sparkGeo = new THREE.BufferGeometry();
    const sparkCount = 30;
    const sparkPositions = new Float32Array(sparkCount * 3);
    for (let i = 0; i < sparkCount * 3; i++) {
      sparkPositions[i] = (Math.random() - 0.5) * 1.5;
    }
    sparkGeo.setAttribute('position', new THREE.BufferAttribute(sparkPositions, 3));
    const sparkMat = new THREE.PointsMaterial({
      color: 0x00ffff,
      size: 0.3,
      transparent: true,
      opacity: 0.9,
    });
    const sparkParticles = new THREE.Points(sparkGeo, sparkMat);
    sparkParticlesRef.current = sparkParticles;
    pantoGroup.add(sparkParticles);

    // --- ANIMATION LOOP ---
    let busX = 0;
    let clock = new THREE.Clock();

    const animate = () => {
      requestAnimationFrame(animate);
      const delta = clock.getDelta();

      // Rotate Wind Turbine Blades
      windTurbineBladesRef.current.forEach((blade) => {
        blade.rotation.z += delta * 2.5;
      });

      // Move Electric Bus along Highway
      if (isPlaying && busGroup) {
        busX += delta * 18 * speedMultiplier;
        if (busX > 80) busX = -80;
        busGroup.position.x = busX;
        setBusPositionX(Math.round(busX));

        // Animate Pantograph Sparks
        if (sparkParticlesRef.current && isPowerActive) {
          const positions = sparkParticlesRef.current.geometry.attributes.position.array as Float32Array;
          for (let i = 0; i < sparkCount * 3; i += 3) {
            positions[i] = (Math.random() - 0.5) * 1.8;
            positions[i + 1] = 2.4 + (Math.random() - 0.5) * 0.4;
            positions[i + 2] = (Math.random() - 0.5) * 0.8;
          }
          sparkParticlesRef.current.geometry.attributes.position.needsUpdate = true;
          sparkParticlesRef.current.visible = true;
        } else if (sparkParticlesRef.current) {
          sparkParticlesRef.current.visible = false;
        }
      }

      // Update Camera based on selected camera mode
      if (cameraRef.current && busGroup) {
        if (cameraView === 'chase') {
          cameraRef.current.position.set(busGroup.position.x - 18, 8, busGroup.position.z + 12);
          cameraRef.current.lookAt(busGroup.position.x + 5, 4, busGroup.position.z);
        } else if (cameraView === 'overhead') {
          cameraRef.current.position.set(0, 60, 0.1);
          cameraRef.current.lookAt(0, 0, 0);
        } else if (cameraView === 'contact') {
          cameraRef.current.position.set(busGroup.position.x - 4, 8, busGroup.position.z + 4);
          cameraRef.current.lookAt(busGroup.position.x, 7.2, busGroup.position.z);
        } else {
          // Free Orbit preset
          cameraRef.current.position.set(30 * Math.cos(Date.now() * 0.0002), 20, 35 * Math.sin(Date.now() * 0.0002));
          cameraRef.current.lookAt(0, 4, 0);
        }
      }

      renderer.render(scene, camera);
    };

    animate();

    // Handle Resize
    const handleResize = () => {
      if (!container || !cameraRef.current || !rendererRef.current) return;
      cameraRef.current.aspect = container.clientWidth / container.clientHeight;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (rendererRef.current && rendererRef.current.domElement) {
        container.removeChild(rendererRef.current.domElement);
      }
    };
  }, [isPlaying, isNightMode, isPowerActive, cameraView, speedMultiplier]);

  return (
    <div className="relative w-full h-[650px] rounded-3xl overflow-hidden border border-cyan-500/30 glass-panel shadow-2xl">
      {/* 3D Canvas Mount */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top Telemetry HUD Overlay */}
      <div className="absolute top-4 left-4 right-4 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
        <div className="flex items-center gap-3 bg-slate-950/80 backdrop-blur-md px-4 py-2 rounded-2xl border border-cyan-500/30 pointer-events-auto">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-emerald-400 animate-ping" />
            <span className="font-tech text-xs text-cyan-300 uppercase tracking-widest font-semibold">
              LIVE 3D CATENARY SIMULATOR
            </span>
          </div>
          <span className="text-xs font-mono text-slate-400 border-l border-slate-700 pl-3">
            BUS POS: <span className="text-white font-bold">{busPositionX}m</span>
          </span>
          <span className="text-xs font-mono text-emerald-400 border-l border-slate-700 pl-3">
            750V DC ACTIVE
          </span>
        </div>

        {/* Camera Preset Selector */}
        <div className="flex items-center gap-1.5 bg-slate-950/80 backdrop-blur-md p-1.5 rounded-2xl border border-slate-800 pointer-events-auto">
          <span className="text-[10px] font-mono text-slate-400 px-2 flex items-center gap-1">
            <Camera className="w-3 h-3 text-cyan-400" /> CAM:
          </span>
          {[
            { id: 'orbit', label: 'Orbit' },
            { id: 'chase', label: 'Bus Chase' },
            { id: 'contact', label: 'Pantograph Zoom' },
            { id: 'overhead', label: 'Grid Top' },
          ].map((mode) => (
            <button
              key={mode.id}
              onClick={() => setCameraView(mode.id as any)}
              className={`px-2.5 py-1 rounded-xl text-xs font-mono transition-all ${
                cameraView === mode.id
                  ? 'bg-cyan-500 text-black font-bold'
                  : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              {mode.label}
            </button>
          ))}
        </div>
      </div>

      {/* Bottom Floating Simulation Controls */}
      <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-center justify-between gap-3 bg-slate-950/90 backdrop-blur-xl p-3.5 rounded-2xl border border-cyan-500/30">
        <div className="flex items-center gap-3">
          {/* Play / Pause Toggle */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-black font-bold hover:scale-105 transition-transform shadow-lg shadow-cyan-500/20"
          >
            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-current" />}
          </button>

          {/* Speed Slider */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-400">SPEED:</span>
            <input
              type="range"
              min="0.2"
              max="3"
              step="0.2"
              value={speedMultiplier}
              onChange={(e) => setSpeedMultiplier(parseFloat(e.target.value))}
              className="w-20 accent-cyan-400 cursor-pointer"
            />
            <span className="text-cyan-300 font-bold w-8 text-right">{speedMultiplier}x</span>
          </div>

          {/* Catenary Power Toggle */}
          <button
            onClick={() => setIsPowerActive(!isPowerActive)}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono flex items-center gap-1.5 border transition-all ${
              isPowerActive
                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400 font-semibold'
                : 'bg-red-500/20 border-red-500 text-red-400'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>CATENARY POWER {isPowerActive ? 'ON' : 'OFF'}</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          {/* Day / Night Toggle */}
          <button
            onClick={() => setIsNightMode(!isNightMode)}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition-colors flex items-center gap-1.5 text-xs font-mono"
          >
            {isNightMode ? (
              <>
                <Moon className="w-4 h-4 text-cyan-400" />
                <span className="hidden sm:inline">Night Cyber</span>
              </>
            ) : (
              <>
                <Sun className="w-4 h-4 text-amber-400" />
                <span className="hidden sm:inline">Day Solar</span>
              </>
            )}
          </button>

          {/* Reset Camera */}
          <button
            onClick={() => {
              setCameraView('orbit');
              setSpeedMultiplier(1);
            }}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-cyan-400 transition-colors"
            title="Reset View"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { 
  Sun, 
  Cpu, 
  Battery, 
  Zap, 
  ShieldCheck, 
  ArrowRight, 
  Play, 
  Pause, 
  RotateCcw, 
  Activity,
  CheckCircle2,
  Sparkles
} from 'lucide-react';

export const HowItWorksAnimated: React.FC = () => {
  const [activeStep, setActiveStep] = useState<number>(0);
  const [isAutoplay, setIsAutoplay] = useState<boolean>(true);

  const steps = [
    {
      id: 1,
      title: 'Solar Panel Array',
      subtitle: 'Photovoltaic Renewable Generation',
      icon: <Sun className="w-6 h-6 text-amber-400" />,
      voltage: '600V - 900V DC',
      role: 'Captures solar irradiance along highway shoulder with bi-facial monocrystalline panels.',
      details: 'Generates green DC power with 23.8% efficiency. Ground albedo reflections add up to +25% extra daytime power.'
    },
    {
      id: 2,
      title: 'MPPT Controller',
      subtitle: 'Maximum Power Point Tracking',
      icon: <Cpu className="w-6 h-6 text-cyan-400" />,
      voltage: '600V DC Regulated',
      role: 'Optimizes solar array impedance for 99.8% energy extraction efficiency.',
      details: 'Uses Perturb & Observe algorithm to adjust operating point every 10 milliseconds under partial cloud cover.'
    },
    {
      id: 3,
      title: 'Battery Bank & Supercap',
      subtitle: 'Hybrid Energy Storage System',
      icon: <Battery className="w-6 h-6 text-emerald-400" />,
      voltage: '640V DC Baseline',
      role: 'Stores baseline green power; supercapacitor buffers high acceleration current spikes.',
      details: '200 kWh LiFePO4 battery handles continuous load while 165F Graphene Supercapacitor provides 3-second burst power.'
    },
    {
      id: 4,
      title: 'Grid Backup Interface',
      subtitle: 'Secondary Utility Fallback',
      icon: <Zap className="w-6 h-6 text-blue-400" />,
      voltage: '11kV AC to 750V DC',
      role: 'Provides bi-directional secondary grid backup during heavy rain, night hours, or extreme traffic density.',
      details: '12-pulse transformer rectifier converts AC grid power with <3% total harmonic distortion.'
    },
    {
      id: 5,
      title: 'Relay / Smart Switching Matrix',
      subtitle: 'ESP32 Solid-State Matrix',
      icon: <ShieldCheck className="w-6 h-6 text-purple-400" />,
      voltage: '750V DC Bus Route',
      role: 'Routes power from best available source in <1 millisecond.',
      details: 'Priority order: Solar PV -> Battery Storage -> Grid Backup -> Supercapacitor Impulse Boost.'
    },
    {
      id: 6,
      title: 'Buck Converter',
      subtitle: 'SiC High-Power DC-DC Step Down',
      icon: <Cpu className="w-6 h-6 text-cyan-400" />,
      voltage: '750V DC Output Regulated',
      role: 'Steps down and regulates variable input to a noise-free 750V DC rail.',
      details: '97.6% SiC MOSFET converter operating at 50 kHz switching frequency to eliminate voltage ripple.'
    },
    {
      id: 7,
      title: 'Catenary Line',
      subtitle: 'Overhead Copper Alloy Contact Wire',
      icon: <Activity className="w-6 h-6 text-amber-400" />,
      voltage: '750V DC Catenary Rail',
      role: 'Suspended wire delivering 750V DC continuously along highway lanes.',
      details: 'Hard-drawn CuAg alloy wire withstands 800A continuous current at speeds up to 120 km/h.'
    },
    {
      id: 8,
      title: 'Pantograph Collector',
      subtitle: 'Roof-Mounted Pneumatic Arm',
      icon: <Zap className="w-6 h-6 text-emerald-400" />,
      voltage: '750V DC Sliding Contact',
      role: 'Maintains sliding contact with catenary line using pneumatic force regulation.',
      details: 'Carbon-copper composite contact strip eliminates spark arcing and provides 99% current collection efficiency.'
    },
    {
      id: 9,
      title: 'Motor Controller (VFD Inverter)',
      subtitle: '3-Phase AC Frequency Inverter',
      icon: <Cpu className="w-6 h-6 text-blue-400" />,
      voltage: '750V DC to 3-Phase AC',
      role: 'Converts DC catenary current into 3-phase variable frequency AC for BLDC motor.',
      details: 'Generates smooth sine wave PWM with regenerative braking energy feedback.'
    },
    {
      id: 10,
      title: 'Electric Transit Bus',
      subtitle: 'In-Motion Charging Heavy Vehicle',
      icon: <Activity className="w-6 h-6 text-cyan-400" />,
      voltage: '750V DC Onboard System',
      role: 'Pulls dynamic power while driving; charges small onboard battery concurrently.',
      details: 'Aerodynamic transit bus with 65% smaller battery weight penalty.'
    },
    {
      id: 11,
      title: 'BLDC Motor Drive',
      subtitle: 'Permanent Magnet Synchronous Drive',
      icon: <Zap className="w-6 h-6 text-emerald-400" />,
      voltage: '250 kW Drive Output',
      role: 'Delivers 2,400 Nm peak torque to drive axle.',
      details: 'Liquid glycol cooled motor delivering 96.5% mechanical drive efficiency.'
    },
    {
      id: 12,
      title: 'Vehicle Movement & Transit',
      subtitle: 'Zero-Emission Highway Acceleration',
      icon: <Sparkles className="w-6 h-6 text-emerald-400" />,
      voltage: '100 km/h Highway Cruise',
      role: 'Smooth zero-emission intercity highway transport with zero depot charging delays.',
      details: 'Reduces lifecycle carbon emissions by 1,245 tons/year per corridor.'
    }
  ];

  useEffect(() => {
    if (!isAutoplay) return;
    const interval = setInterval(() => {
      setActiveStep((prev) => (prev + 1) % steps.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [isAutoplay, steps.length]);

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
      {/* Title */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
          <Activity className="w-4 h-4 animate-pulse" />
          <span>REAL-TIME POWER FLOW SIMULATION</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-tech text-white">
          HOW IT <span className="text-cyan-400">WORKS</span>
        </h2>
        <p className="text-slate-300 max-w-2xl mx-auto text-sm sm:text-base">
          Interactive step-by-step energy trajectory from Solar PV generation to dynamic Highway BLDC motor propulsion.
        </p>
      </div>

      {/* Control Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4 glass-panel p-4 rounded-2xl border-cyan-500/30">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsAutoplay(!isAutoplay)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-black font-tech font-bold text-xs flex items-center gap-2 hover:scale-105 transition-transform"
          >
            {isAutoplay ? (
              <>
                <Pause className="w-4 h-4" />
                <span>PAUSE FLOW</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>PLAY POWER FLOW</span>
              </>
            )}
          </button>

          <button
            onClick={() => setActiveStep(0)}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-400 transition-colors"
            title="Reset Flow"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Current Active Step Display */}
        <div className="text-xs font-mono text-cyan-300 bg-cyan-950/60 px-4 py-2 rounded-xl border border-cyan-500/30 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span>STAGE {activeStep + 1} OF 12: <strong className="text-white uppercase">{steps[activeStep].title}</strong></span>
        </div>
      </div>

      {/* Interactive Step Sequence Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {steps.map((step, idx) => {
          const isActive = idx === activeStep;
          const isPassed = idx < activeStep;

          return (
            <div
              key={step.id}
              onClick={() => {
                setActiveStep(idx);
                setIsAutoplay(false);
              }}
              className={`p-5 rounded-3xl cursor-pointer transition-all duration-300 relative overflow-hidden glass-panel ${
                isActive
                  ? 'border-cyan-400 bg-cyan-950/60 shadow-2xl shadow-cyan-500/30 scale-105 z-10'
                  : isPassed
                  ? 'border-emerald-500/40 bg-slate-900/90'
                  : 'hover:border-slate-700'
              }`}
            >
              {/* Electric Current Flow Pulse Line */}
              {isActive && (
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-400 via-emerald-400 to-cyan-400 animate-pulse" />
              )}

              <div className="flex items-center justify-between gap-2 mb-3">
                <span className={`w-7 h-7 rounded-xl flex items-center justify-center font-mono text-xs font-bold ${
                  isActive
                    ? 'bg-cyan-500 text-black'
                    : isPassed
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    : 'bg-slate-800 text-slate-400'
                }`}>
                  {step.id}
                </span>
                <span className="text-[10px] font-mono text-cyan-400 font-semibold bg-slate-900 px-2 py-0.5 rounded-lg border border-slate-800">
                  {step.voltage}
                </span>
              </div>

              <div className="flex items-center gap-2 mb-2">
                {step.icon}
                <h3 className="font-tech text-sm font-bold text-white truncate">{step.title}</h3>
              </div>

              <p className="text-[11px] text-slate-300 line-clamp-2 leading-relaxed">
                {step.role}
              </p>
            </div>
          );
        })}
      </div>

      {/* Active Step Detailed Information Panel */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border-cyan-500/40 bg-gradient-to-r from-slate-950 via-cyan-950/30 to-slate-950 relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border-b border-cyan-500/20 pb-6">
          <div className="flex items-center gap-4">
            <div className="p-4 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-400 shadow-lg shadow-cyan-500/20">
              {steps[activeStep].icon}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-cyan-400 font-bold">STEP {steps[activeStep].id} OF 12</span>
                <span className="text-xs font-mono text-emerald-400 border-l border-slate-700 pl-2">ACTIVE CURRENT PATH</span>
              </div>
              <h3 className="font-tech text-2xl font-bold text-white">{steps[activeStep].title}</h3>
              <p className="text-xs font-mono text-slate-400">{steps[activeStep].subtitle}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-4 py-2 rounded-2xl bg-slate-900 border border-cyan-500/30 font-mono text-xs text-cyan-300">
              OPERATING VOLTAGE: <strong className="text-white font-bold">{steps[activeStep].voltage}</strong>
            </div>
          </div>
        </div>

        <div className="pt-6 grid md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <h4 className="font-tech text-xs font-semibold text-cyan-400 uppercase tracking-wider">Functional Role</h4>
            <p className="text-sm text-slate-200 leading-relaxed font-sans">{steps[activeStep].role}</p>
          </div>
          <div className="space-y-2">
            <h4 className="font-tech text-xs font-semibold text-emerald-400 uppercase tracking-wider">Technical Implementation Specs</h4>
            <p className="text-sm text-slate-300 leading-relaxed font-sans">{steps[activeStep].details}</p>
          </div>
        </div>
      </div>
    </section>
  );
};

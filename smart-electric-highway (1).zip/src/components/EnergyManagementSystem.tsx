import React, { useState } from 'react';
import { Zap, Sun, Battery, Activity, ArrowRight, ShieldCheck, Sliders, AlertTriangle } from 'lucide-react';

export const EnergyManagementSystem: React.FC = () => {
  const [solarIrradiance, setSolarIrradiance] = useState<number>(850); // W/m²
  const [gridAvailable, setGridAvailable] = useState<boolean>(true);
  const [batterySOC, setBatterySOC] = useState<number>(82); // %
  const [powerDemand, setPowerDemand] = useState<number>(180); // kW demand from bus

  // Calculate live power generated
  const solarOutputKw = Math.round((solarIrradiance / 1000) * 220); // max 220kW solar
  const isSolarDominant = solarOutputKw >= powerDemand;
  const isBatteryActive = !isSolarDominant && batterySOC > 20;
  const isGridActive = !isSolarDominant && (!isBatteryActive || batterySOC <= 30) && gridAvailable;
  const isSupercapActive = powerDemand > 250; // Supercap fires on acceleration bursts >250kW

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
      {/* Title */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
          <Zap className="w-4 h-4 animate-pulse" />
          <span>MICROGRID AUTOMATED CONTROL</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-tech text-white">
          ENERGY MANAGEMENT <span className="text-cyan-400">SYSTEM (EMS)</span>
        </h2>
        <p className="text-slate-300 max-w-2xl mx-auto text-sm sm:text-base">
          Real-time dynamic power switching matrix. Test different environmental conditions and watch the ESP32 microcontroller route zero-emission power.
        </p>
      </div>

      {/* Priority Logic Banner */}
      <div className="glass-panel p-6 rounded-3xl border-cyan-500/30 bg-gradient-to-r from-slate-950 via-cyan-950/20 to-slate-950">
        <h3 className="font-tech text-xs font-semibold text-cyan-400 uppercase tracking-widest mb-4 text-center">
          SUB-MILLISECOND ENERGY ROUTING PRIORITY HIERARCHY
        </h3>
        <div className="flex flex-wrap items-center justify-center gap-3">
          {[
            { step: '1', title: 'SOLAR PV', sub: 'Primary Green Generation', color: 'border-amber-500 text-amber-400' },
            { step: '2', title: 'GRID BACKUP', sub: 'Secondary Substation Rail', color: 'border-blue-500 text-blue-400' },
            { step: '3', title: 'BATTERY BANK', sub: 'LiFePO4 Storage Buffer', color: 'border-emerald-500 text-emerald-400' },
            { step: '4', title: 'SUPERCAPACITOR', sub: 'Peak Pulse Acceleration', color: 'border-purple-500 text-purple-400' },
          ].map((item, idx) => (
            <React.Fragment key={item.step}>
              <div className={`p-4 rounded-2xl bg-slate-900 border ${item.color} text-center min-w-[160px]`}>
                <span className="text-[10px] font-mono text-slate-400">PRIORITY {item.step}</span>
                <h4 className="font-tech text-sm font-bold mt-0.5">{item.title}</h4>
                <p className="text-[10px] text-slate-400 mt-1">{item.sub}</p>
              </div>
              {idx < 3 && <ArrowRight className="w-4 h-4 text-slate-600 hidden sm:block" />}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Interactive Sliders & Live Controller Simulation */}
      <div className="grid lg:grid-cols-12 gap-8">
        {/* Left 5 cols: Environmental Inputs */}
        <div className="lg:col-span-5 glass-panel p-6 sm:p-8 rounded-3xl space-y-6">
          <h3 className="font-tech text-lg font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <Sliders className="w-5 h-5 text-cyan-400" />
            <span>ENVIRONMENTAL PARAMETERS</span>
          </h3>

          {/* Solar Irradiance */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-300">SOLAR IRRADIANCE:</span>
              <span className="text-amber-400 font-bold">{solarIrradiance} W/m²</span>
            </div>
            <input
              type="range"
              min="0"
              max="1200"
              value={solarIrradiance}
              onChange={(e) => setSolarIrradiance(parseInt(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />
            <p className="text-[11px] text-slate-400 font-mono">Generates approx. {solarOutputKw} kW PV output</p>
          </div>

          {/* Bus Power Demand */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-300">BUS POWER DEMAND:</span>
              <span className="text-cyan-400 font-bold">{powerDemand} kW</span>
            </div>
            <input
              type="range"
              min="50"
              max="350"
              value={powerDemand}
              onChange={(e) => setPowerDemand(parseInt(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer"
            />
            <p className="text-[11px] text-slate-400 font-mono">
              {powerDemand > 250 ? '⚡ Peak Burst Demand Triggered!' : 'Nominal Cruise Transit Load'}
            </p>
          </div>

          {/* Battery State of Charge */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-300">BATTERY SOC:</span>
              <span className="text-emerald-400 font-bold">{batterySOC}%</span>
            </div>
            <input
              type="range"
              min="10"
              max="100"
              value={batterySOC}
              onChange={(e) => setBatterySOC(parseInt(e.target.value))}
              className="w-full accent-emerald-400 cursor-pointer"
            />
          </div>

          {/* Grid Availability */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-900 border border-slate-800">
            <span className="text-xs font-mono text-slate-300">UTILITY GRID SUBSTATION:</span>
            <button
              onClick={() => setGridAvailable(!gridAvailable)}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-colors ${
                gridAvailable ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-red-500/20 text-red-400 border border-red-500/40'
              }`}
            >
              {gridAvailable ? 'ACTIVE' : 'DISCONNECTED'}
            </button>
          </div>
        </div>

        {/* Right 7 cols: Live Switching Matrix & Flow Visualizer */}
        <div className="lg:col-span-7 glass-panel p-6 sm:p-8 rounded-3xl space-y-6 border-cyan-500/40 bg-gradient-to-b from-slate-900 to-slate-950">
          <div className="flex items-center justify-between border-b border-cyan-500/20 pb-4">
            <div>
              <span className="text-xs font-mono text-cyan-400 font-bold uppercase">ESP32 REAL-TIME CONTROLLER STATUS</span>
              <h3 className="font-tech text-xl font-bold text-white mt-0.5">ACTIVE DYNAMIC ROUTING PATH</h3>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-xs font-mono text-emerald-400 font-bold">1ms RESPONSE TIME</span>
            </div>
          </div>

          {/* Active Flow Diagram */}
          <div className="space-y-4">
            {/* Solar Node */}
            <div className={`p-4 rounded-2xl border transition-all flex items-center justify-between ${
              isSolarDominant
                ? 'bg-amber-950/40 border-amber-500 shadow-lg shadow-amber-500/20'
                : 'bg-slate-900/60 border-slate-800 opacity-60'
            }`}>
              <div className="flex items-center gap-3">
                <Sun className={`w-6 h-6 ${isSolarDominant ? 'text-amber-400 animate-spin' : 'text-slate-500'}`} />
                <div>
                  <h4 className="font-tech text-sm font-bold text-white">SOLAR PV ARRAY</h4>
                  <span className="text-xs font-mono text-slate-400">Gen: {solarOutputKw} kW</span>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-xl text-xs font-mono font-bold ${
                isSolarDominant ? 'bg-amber-500 text-black' : 'bg-slate-800 text-slate-500'
              }`}>
                {isSolarDominant ? 'DOMINANT SUPPLY' : 'STANDBY'}
              </span>
            </div>

            {/* Battery Storage Node */}
            <div className={`p-4 rounded-2xl border transition-all flex items-center justify-between ${
              isBatteryActive
                ? 'bg-emerald-950/40 border-emerald-500 shadow-lg shadow-emerald-500/20'
                : 'bg-slate-900/60 border-slate-800 opacity-60'
            }`}>
              <div className="flex items-center gap-3">
                <Battery className={`w-6 h-6 ${isBatteryActive ? 'text-emerald-400 animate-pulse' : 'text-slate-500'}`} />
                <div>
                  <h4 className="font-tech text-sm font-bold text-white">LiFePO4 BATTERY BANK</h4>
                  <span className="text-xs font-mono text-slate-400">SOC: {batterySOC}%</span>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-xl text-xs font-mono font-bold ${
                isBatteryActive ? 'bg-emerald-500 text-black' : 'bg-slate-800 text-slate-500'
              }`}>
                {isBatteryActive ? 'DISCHARGING SUPPLY' : 'IDLE / RECHARGING'}
              </span>
            </div>

            {/* Grid Substation Node */}
            <div className={`p-4 rounded-2xl border transition-all flex items-center justify-between ${
              isGridActive
                ? 'bg-blue-950/40 border-blue-500 shadow-lg shadow-blue-500/20'
                : 'bg-slate-900/60 border-slate-800 opacity-60'
            }`}>
              <div className="flex items-center gap-3">
                <Zap className={`w-6 h-6 ${isGridActive ? 'text-blue-400 animate-pulse' : 'text-slate-500'}`} />
                <div>
                  <h4 className="font-tech text-sm font-bold text-white">UTILITY GRID SUBSTATION</h4>
                  <span className="text-xs font-mono text-slate-400">Status: {gridAvailable ? 'Connected' : 'Offline'}</span>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-xl text-xs font-mono font-bold ${
                isGridActive ? 'bg-blue-500 text-black' : 'bg-slate-800 text-slate-500'
              }`}>
                {isGridActive ? 'GRID BACKUP ACTIVE' : 'OFFGRID STANDBY'}
              </span>
            </div>

            {/* Supercapacitor Boost Node */}
            <div className={`p-4 rounded-2xl border transition-all flex items-center justify-between ${
              isSupercapActive
                ? 'bg-purple-950/40 border-purple-500 shadow-lg shadow-purple-500/20'
                : 'bg-slate-900/60 border-slate-800 opacity-60'
            }`}>
              <div className="flex items-center gap-3">
                <ShieldCheck className={`w-6 h-6 ${isSupercapActive ? 'text-purple-400 animate-bounce' : 'text-slate-500'}`} />
                <div>
                  <h4 className="font-tech text-sm font-bold text-white">SUPERCAPACITOR IMPULSE</h4>
                  <span className="text-xs font-mono text-slate-400">Discharge Rate: {isSupercapActive ? '120 kW Burst' : '0 kW'}</span>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-xl text-xs font-mono font-bold ${
                isSupercapActive ? 'bg-purple-500 text-black' : 'bg-slate-800 text-slate-500'
              }`}>
                {isSupercapActive ? 'PEAK BURST BOOST' : 'READY'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

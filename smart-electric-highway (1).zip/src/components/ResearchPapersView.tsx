import React, { useState } from 'react';
import { RESEARCH_PAPERS } from '../data/projectData';
import { ResearchPaper } from '../types';
import { BookOpen, FileText, ExternalLink, Download, Check, Sparkles, Quote } from 'lucide-react';

export const ResearchPapersView: React.FC = () => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyCitation = (paper: ResearchPaper) => {
    const citation = `${paper.authors.join(', ')}, "${paper.title}," ${paper.journal}, vol. 12, pp. 102-115, ${paper.year}. DOI: ${paper.doi}`;
    navigator.clipboard.writeText(citation);
    setCopiedId(paper.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
      {/* Title */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
          <BookOpen className="w-4 h-4" />
          <span>IEEE TRANSACTIONS & PEER-REVIEWED PUBLICATIONS</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-tech text-white">
          RESEARCH <span className="text-cyan-400">PAPERS</span>
        </h2>
        <p className="text-slate-300 max-w-2xl mx-auto text-sm sm:text-base">
          Published literature supporting the catenary power transfer dynamics, HESS microgrid optimization, and lifecycle economic models.
        </p>
      </div>

      {/* Research Papers Grid */}
      <div className="space-y-6">
        {RESEARCH_PAPERS.map((paper) => (
          <div key={paper.id} className="glass-panel p-6 sm:p-8 rounded-3xl border-cyan-500/20 glass-panel-hover space-y-6">
            <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-800 pb-4">
              <div className="space-y-2 max-w-3xl">
                <div className="flex flex-wrap items-center gap-2 font-mono text-xs text-cyan-400">
                  <span className="px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/40 font-bold">{paper.journal}</span>
                  <span>• {paper.year}</span>
                  <span>• DOI: {paper.doi}</span>
                </div>
                <h3 className="font-tech text-xl sm:text-2xl font-bold text-white">{paper.title}</h3>
                <p className="text-xs font-mono text-slate-400">Authors: <strong className="text-slate-200">{paper.authors.join(', ')}</strong></p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => copyCitation(paper)}
                  className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-mono flex items-center gap-1.5 transition-colors"
                >
                  {copiedId === paper.id ? <Check className="w-4 h-4 text-emerald-400" /> : <Quote className="w-4 h-4 text-cyan-400" />}
                  <span>{copiedId === paper.id ? 'COPIED!' : 'CITE PAPER'}</span>
                </button>
              </div>
            </div>

            {/* Abstract Summary */}
            <div className="space-y-2">
              <h4 className="font-tech text-xs font-semibold text-cyan-400 uppercase tracking-wider">Executive Abstract</h4>
              <p className="text-sm text-slate-300 leading-relaxed font-sans">{paper.summary}</p>
            </div>

            {/* Key Findings Bullet Grid */}
            <div className="space-y-2">
              <h4 className="font-tech text-xs font-semibold text-emerald-400 uppercase tracking-wider">Key Empirical Findings</h4>
              <div className="grid sm:grid-cols-3 gap-3">
                {paper.keyFindings.map((finding, idx) => (
                  <div key={idx} className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 font-mono flex items-start gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{finding}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

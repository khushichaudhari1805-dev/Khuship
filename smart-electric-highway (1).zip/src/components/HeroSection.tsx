import React, { useState, useEffect } from 'react';
import { HOME_STATS, PROJECT_INFO } from '../data/projectData';
import { NavTab } from '../types';
import { Zap, Play, FileText, ArrowRight, ShieldCheck, Activity, Cpu, Radio, Sparkles } from 'lucide-react';

interface HeroSectionProps {
  onNavigate: (tab: NavTab) => void;
  onOpenReportModal: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onNavigate, onOpenReportModal }) => {
  const [activeStatIndex, setActiveStatIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveStatIndex((prev) => (prev + 1) % HOME_STATS.length);
    }, 3500);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative min-h-[90vh] flex flex-col justify-center items-center py-12 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Animated Electric Grid & Catenary Line Graphic in Background */}
      <div className="absolute inset-0 pointer-events-none opacity-20 bg-grid-pattern" />

      {/* Hero Content Container */}
      <div className="relative z-10 max-w-5xl mx-auto text-center space-y-8">
        
        {/* Top Floating Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900/90 border border-cyan-500/40 shadow-lg shadow-cyan-500/10 backdrop-blur-xl animate-electric-pulse">
          <Sparkles className="w-4 h-4 text-cyan-400 animate-spin" />
          <span className="text-xs font-mono font-semibold tracking-wider text-cyan-300 uppercase">
            IEEE MAJOR ENGINEERING PROJECT • 2025-2026
          </span>
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
        </div>

        {/* Main Title */}
        <div className="space-y-4">
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold font-tech tracking-tight text-white leading-tight">
            SMART <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-emerald-400 to-cyan-200">ELECTRIC HIGHWAY</span>
          </h1>
          <p className="text-lg sm:text-2xl font-light font-tech text-cyan-200/90 max-w-3xl mx-auto tracking-wide">
            USING OVERHEAD LINE AND HYBRID ENERGY STORAGE
          </p>
          <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed font-sans">
            {PROJECT_INFO.tagline}
          </p>
        </div>

        {/* Call to Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
          {/* Explore Project */}
          <button
            onClick={() => onNavigate('how-it-works')}
            className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-black font-tech font-bold text-sm tracking-wider flex items-center gap-2 hover:scale-105 transition-all shadow-xl shadow-cyan-500/25 group"
          >
            <span>EXPLORE PROJECT</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          {/* View Live 3D Simulation */}
          <button
            onClick={() => onNavigate('3d-simulation')}
            className="px-6 py-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-cyan-500/40 text-cyan-300 font-tech font-bold text-sm tracking-wider flex items-center gap-2 transition-all hover:border-cyan-400 shadow-lg shadow-cyan-500/10"
          >
            <Play className="w-4 h-4 text-emerald-400 fill-current" />
            <span>LIVE 3D SIMULATION</span>
          </button>

          {/* Download Technical Report */}
          <button
            onClick={onOpenReportModal}
            className="px-6 py-3.5 rounded-2xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-700/80 text-slate-200 font-tech font-bold text-sm tracking-wider flex items-center gap-2 transition-all"
          >
            <FileText className="w-4 h-4 text-cyan-400" />
            <span>DOWNLOAD IEEE REPORT</span>
          </button>
        </div>

        {/* Live System Ticker */}
        <div className="pt-4 flex flex-wrap items-center justify-center gap-6 text-xs font-mono text-slate-400">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Catenary Grid: <strong className="text-emerald-400">750V DC Synchronized</strong></span>
          </div>
          <div className="flex items-center gap-1.5">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <span>ESP32 IoT Node: <strong className="text-cyan-300">Connected</strong></span>
          </div>
          <div className="flex items-center gap-1.5">
            <Radio className="w-4 h-4 text-emerald-400" />
            <span>Hybrid Storage: <strong className="text-emerald-400 font-mono">LiFePO4 + Supercapacitor</strong></span>
          </div>
        </div>

      </div>

      {/* Animated Key Statistics Cards Grid */}
      <div className="relative z-10 w-full max-w-6xl mx-auto mt-16">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
          {HOME_STATS.map((stat, idx) => {
            const isHighlight = idx === activeStatIndex;
            return (
              <div
                key={stat.id}
                onClick={() => setActiveStatIndex(idx)}
                className={`p-4 rounded-2xl cursor-pointer transition-all duration-300 glass-panel ${
                  isHighlight
                    ? 'border-cyan-400 bg-cyan-950/40 shadow-xl shadow-cyan-500/20 scale-105'
                    : 'hover:border-cyan-500/30'
                }`}
              >
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider truncate">
                    {stat.label}
                  </span>
                  <Activity className={`w-3 h-3 ${isHighlight ? 'text-cyan-400' : 'text-slate-600'}`} />
                </div>
                <div className="flex items-baseline gap-0.5">
                  <span className="font-tech text-xl sm:text-2xl font-bold text-white">
                    {stat.value}
                  </span>
                  <span className="font-tech text-xs text-cyan-400 font-semibold">
                    {stat.suffix}
                  </span>
                </div>
                <div className="text-[10px] font-mono text-emerald-400 mt-1 flex items-center gap-1">
                  <span>{stat.change}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

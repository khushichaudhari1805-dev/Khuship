import React, { useState } from 'react';
import { DollarSign, TrendingUp, Sliders, BarChart2, ShieldCheck, Leaf, Clock } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

export const CostAnalysisView: React.FC = () => {
  const [highwayKm, setHighwayKm] = useState<number>(25); // 25 km corridor
  const [dailyBuses, setDailyBuses] = useState<number>(60); // 60 transit buses per day

  // Cost calculations
  const catenaryCapEx = highwayKm * 85000; // $85,000 / km
  const solarCapEx = highwayKm * 42000; // $42,000 / km solar array
  const hessCapEx = 120000; // $120,000 substation HESS storage
  const totalCapEx = catenaryCapEx + solarCapEx + hessCapEx;

  // Annual savings vs Diesel Bus Fleet
  // Diesel bus consumes approx $0.65 / km fuel. Catenary EV consumes $0.18 / km solar/grid power.
  const annualKmPerBus = 75000; // 75k km/yr
  const annualFuelSavingsPerBus = annualKmPerBus * (0.65 - 0.18);
  const totalAnnualSavings = dailyBuses * annualFuelSavingsPerBus;

  const paybackPeriodYears = (totalCapEx / totalAnnualSavings).toFixed(1);
  const ROIPercentage = ((totalAnnualSavings / totalCapEx) * 100).toFixed(1);
  const annualCarbonSavedTons = Math.round(dailyBuses * 28.5); // 28.5 tons CO2 saved per electric bus/yr

  const financialComparisonData = [
    { year: 'Year 1', DieselCapEx: 1500000, DieselOpEx: 2925000, ElectricHighwayCapEx: totalCapEx, ElectricHighwayOpEx: 810000 },
    { year: 'Year 3', DieselCapEx: 1500000, DieselOpEx: 8775000, ElectricHighwayCapEx: totalCapEx, ElectricHighwayOpEx: 2430000 },
    { year: 'Year 5', DieselCapEx: 1500000, DieselOpEx: 14625000, ElectricHighwayCapEx: totalCapEx, ElectricHighwayOpEx: 4050000 },
    { year: 'Year 10', DieselCapEx: 3000000, DieselOpEx: 29250000, ElectricHighwayCapEx: totalCapEx, ElectricHighwayOpEx: 8100000 },
  ];

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
      {/* Title */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
          <DollarSign className="w-4 h-4" />
          <span>TECHNO-ECONOMIC CAPITAL & SAVINGS ANALYSIS</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-tech text-white">
          COST ANALYSIS <span className="text-cyan-400">& ROI</span>
        </h2>
        <p className="text-slate-300 max-w-2xl mx-auto text-sm sm:text-base">
          Interactive techno-economic model. Adjust corridor scale and bus traffic density to project capital expenses, operational expenditure savings, and payback period.
        </p>
      </div>

      {/* Interactive Scale Controller Sliders */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border-cyan-500/40 bg-gradient-to-r from-slate-950 via-cyan-950/20 to-slate-950 space-y-6">
        <h3 className="font-tech text-lg font-bold text-white flex items-center gap-2 border-b border-cyan-500/20 pb-3">
          <Sliders className="w-5 h-5 text-cyan-400" />
          <span>PROJECT PARAMETERS CALCULATOR</span>
        </h3>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Highway Length Slider */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-300">HIGHWAY CORRIDOR LENGTH:</span>
              <span className="text-cyan-400 font-bold">{highwayKm} km</span>
            </div>
            <input
              type="range"
              min="5"
              max="150"
              value={highwayKm}
              onChange={(e) => setHighwayKm(parseInt(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer"
            />
          </div>

          {/* Daily Buses Slider */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-300">DAILY TRANSIT BUSES:</span>
              <span className="text-emerald-400 font-bold">{dailyBuses} Buses/Day</span>
            </div>
            <input
              type="range"
              min="10"
              max="300"
              value={dailyBuses}
              onChange={(e) => setDailyBuses(parseInt(e.target.value))}
              className="w-full accent-emerald-400 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Calculated Financial Key Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {/* Total CapEx */}
        <div className="glass-panel p-5 rounded-2xl border-cyan-500/30 space-y-2">
          <span className="text-[10px] font-mono text-slate-400 uppercase">CAPITAL EXPENSE (CapEx)</span>
          <div className="font-tech text-2xl font-bold text-white">
            ${(totalCapEx / 1000000).toFixed(2)}M
          </div>
          <p className="text-[10px] font-mono text-slate-400">Includes Catenary + Solar + HESS</p>
        </div>

        {/* Annual Fuel Savings */}
        <div className="glass-panel p-5 rounded-2xl border-emerald-500/30 space-y-2">
          <span className="text-[10px] font-mono text-slate-400 uppercase">ANNUAL OPEX SAVINGS</span>
          <div className="font-tech text-2xl font-bold text-emerald-400">
            ${(totalAnnualSavings / 1000000).toFixed(2)}M / yr
          </div>
          <p className="text-[10px] font-mono text-emerald-300">vs Diesel Transit Fleet</p>
        </div>

        {/* Payback Period */}
        <div className="glass-panel p-5 rounded-2xl border-amber-500/30 space-y-2">
          <span className="text-[10px] font-mono text-slate-400 uppercase">PAYBACK PERIOD</span>
          <div className="font-tech text-2xl font-bold text-amber-400">
            {paybackPeriodYears} Years
          </div>
          <p className="text-[10px] font-mono text-amber-300">ROI: {ROIPercentage}% per year</p>
        </div>

        {/* Annual CO2 Reduction */}
        <div className="glass-panel p-5 rounded-2xl border-cyan-500/30 space-y-2">
          <span className="text-[10px] font-mono text-slate-400 uppercase">CO₂ REDUCTION</span>
          <div className="font-tech text-2xl font-bold text-cyan-300">
            {annualCarbonSavedTons} Tons/yr
          </div>
          <p className="text-[10px] font-mono text-cyan-400">Zero Direct Exhaust</p>
        </div>
      </div>

      {/* Financial Comparison Chart */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl space-y-4 border-cyan-500/30">
        <h3 className="font-tech text-lg font-bold text-white border-b border-slate-800 pb-3">
          10-YEAR CUMULATIVE EXPENDITURE COMPARISON ($ USD)
        </h3>
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={financialComparisonData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="year" stroke="#64748b" fontSize={12} />
              <YAxis stroke="#64748b" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#06b6d4', borderRadius: '12px' }} />
              <Bar dataKey="DieselOpEx" fill="#ef4444" name="Diesel Fleet Operational Cost ($)" radius={[6, 6, 0, 0]} />
              <Bar dataKey="ElectricHighwayOpEx" fill="#10b981" name="Electric Highway Operational Cost ($)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </section>
  );
};

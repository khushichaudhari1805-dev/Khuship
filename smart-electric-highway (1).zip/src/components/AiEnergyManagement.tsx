import React, { useState } from 'react';
import { Sparkles, Brain, Cpu, ShieldAlert, Activity, CheckCircle, RefreshCw, BarChart2 } from 'lucide-react';

export const AiEnergyManagement: React.FC = () => {
  const [isRunningDiagnostic, setIsRunningDiagnostic] = useState(false);
  const [diagnosticResult, setDiagnosticResult] = useState<string | null>(null);

  const runAiDiagnostic = () => {
    setIsRunningDiagnostic(true);
    setDiagnosticResult(null);
    setTimeout(() => {
      setIsRunningDiagnostic(false);
      setDiagnosticResult('ALL SYSTEMS NOMINAL: LSTM model predicts 98.4% Battery SOH over next 1,000 cycles. Solar array output forecasted +14% at 14:00.');
    }, 2000);
  };

  const aiFeatures = [
    {
      title: 'Solar Irradiance Neural Network',
      desc: 'Predicts solar PV generation up to 4 hours in advance using cloud vector vision models, allowing the microgrid to pre-route battery reserves.',
      accuracy: '98.2% Accuracy',
      icon: <Brain className="w-5 h-5 text-amber-400" />
    },
    {
      title: 'Battery SOH Degradation LSTM Model',
      desc: 'Monitors micro-impedance changes during high-power pantograph charging to prevent lithium plating and optimize cell thermal balancing.',
      accuracy: '+38% Cycle Life Extension',
      icon: <Activity className="w-5 h-5 text-emerald-400" />
    },
    {
      title: 'Dynamic Highway Load Forecasting',
      desc: 'Predicts electric transit bus density at highway entry tolls, automatically pre-charging roadside supercapacitors before bus arrival.',
      accuracy: '< 850µs Switching Speed',
      icon: <Cpu className="w-5 h-5 text-cyan-400" />
    },
    {
      title: 'Real-Time Arc Fault & Anomaly Detection',
      desc: 'Optical and high-frequency RF spectrum analysis detecting pantograph contact arcing in real-time, automatically adjusting pneumatic pressure.',
      accuracy: '99.9% Fault Prevention',
      icon: <ShieldAlert className="w-5 h-5 text-red-400" />
    }
  ];

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
      {/* Title */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
          <Sparkles className="w-4 h-4 animate-spin" />
          <span>AUTONOMOUS NEURAL ENERGY OPTIMIZATION</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-tech text-white">
          AI ENERGY <span className="text-cyan-400">MANAGEMENT</span>
        </h2>
        <p className="text-slate-300 max-w-2xl mx-auto text-sm sm:text-base">
          Predictive machine learning algorithms governing energy distribution, battery state of health, and automated highway arc fault prevention.
        </p>
      </div>

      {/* AI Features Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {aiFeatures.map((feat, idx) => (
          <div key={idx} className="glass-panel p-6 sm:p-8 rounded-3xl border-cyan-500/20 glass-panel-hover space-y-4">
            <div className="flex items-center justify-between">
              <div className="p-3 rounded-2xl bg-cyan-500/10 border border-cyan-500/30">
                {feat.icon}
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-400 text-xs font-mono font-bold">
                {feat.accuracy}
              </span>
            </div>
            <h3 className="font-tech text-xl font-bold text-white">{feat.title}</h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">{feat.desc}</p>
          </div>
        ))}
      </div>

      {/* Diagnostic Trigger Panel */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border-cyan-500/40 bg-gradient-to-r from-slate-950 via-cyan-950/30 to-slate-950 text-center space-y-6">
        <div className="max-w-xl mx-auto space-y-2">
          <h3 className="font-tech text-2xl font-bold text-white">AI DIAGNOSTIC & HEALTH PREDICTION ENGINE</h3>
          <p className="text-xs font-mono text-cyan-300">Run a simulated real-time neural network evaluation across the highway catenary network.</p>
        </div>

        <button
          onClick={runAiDiagnostic}
          disabled={isRunningDiagnostic}
          className="px-8 py-4 rounded-2xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-black font-tech font-bold text-sm tracking-wider hover:scale-105 transition-all shadow-xl shadow-cyan-500/20 flex items-center gap-2 mx-auto disabled:opacity-50"
        >
          <RefreshCw className={`w-5 h-5 ${isRunningDiagnostic ? 'animate-spin' : ''}`} />
          <span>{isRunningDiagnostic ? 'RUNNING NEURAL MODEL DIAGNOSTICS...' : 'EXECUTE AI SYSTEM DIAGNOSTIC'}</span>
        </button>

        {diagnosticResult && (
          <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/50 text-emerald-300 text-xs font-mono max-w-2xl mx-auto flex items-center gap-3 animate-fadeIn">
            <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="text-left">{diagnosticResult}</span>
          </div>
        )}
      </div>
    </section>
  );
};

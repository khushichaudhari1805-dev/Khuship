import React, { useState } from 'react';
import { TEAM_MEMBERS, PROJECT_INFO } from '../data/projectData';
import { Mail, Github, Linkedin, Award, Send, CheckCircle, QrCode, Phone, MapPin, Building } from 'lucide-react';

export const ContactTeamView: React.FC = () => {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
    setTimeout(() => {
      setFormSubmitted(false);
      setFormData({ name: '', email: '', subject: '', message: '' });
    }, 4000);
  };

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-16">
      {/* Title */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
          <Phone className="w-4 h-4" />
          <span>PROJECT CREDENTIALS & INQUIRIES</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-tech text-white">
          TEAM & <span className="text-cyan-400">CONTACT</span>
        </h2>
        <p className="text-slate-300 max-w-2xl mx-auto text-sm sm:text-base">
          Major Project Team, Department of Electrical & Electronics Engineering. Reach out for collaboration or IEEE research inquiries.
        </p>
      </div>

      {/* University & Department Banner */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border-cyan-500/30 bg-gradient-to-r from-slate-950 via-cyan-950/20 to-slate-950 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center md:text-left">
          <span className="text-xs font-mono text-cyan-400 font-bold uppercase">{PROJECT_INFO.university}</span>
          <h3 className="font-tech text-2xl font-bold text-white">{PROJECT_INFO.college}</h3>
          <p className="text-xs font-mono text-slate-400">Project Guide: <strong className="text-slate-200">{PROJECT_INFO.guidedBy}</strong></p>
        </div>
        
        {/* Interactive QR Code Simulator */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-cyan-500/30 flex items-center gap-4">
          <div className="w-20 h-20 bg-white p-1 rounded-xl flex items-center justify-center">
            <QrCode className="w-16 h-16 text-black" />
          </div>
          <div className="text-left font-mono text-xs">
            <span className="text-cyan-400 font-bold block">SCAN TO SHARE</span>
            <span className="text-slate-400 text-[10px] block mt-1">Smart Electric Highway IEEE Major Project Site</span>
          </div>
        </div>
      </div>

      {/* Team Members Grid */}
      <div className="grid md:grid-cols-3 gap-6">
        {TEAM_MEMBERS.map((member, idx) => (
          <div key={idx} className="glass-panel p-6 rounded-3xl border-cyan-500/20 glass-panel-hover space-y-4 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-16 h-16 rounded-2xl object-cover border-2 border-cyan-500/40 shadow-lg shadow-cyan-500/20"
                />
                <div>
                  <h3 className="font-tech text-lg font-bold text-white">{member.name}</h3>
                  <p className="text-xs font-mono text-cyan-400">{member.role}</p>
                  {member.studentId && <p className="text-[10px] font-mono text-slate-500">ID: {member.studentId}</p>}
                </div>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">{member.bio}</p>
            </div>

            <div className="pt-4 border-t border-slate-800 flex items-center gap-3">
              <a href={`mailto:${member.email}`} className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-cyan-400 transition-colors">
                <Mail className="w-4 h-4" />
              </a>
              {member.github && (
                <a href={member.github} target="_blank" rel="noreferrer" className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-colors">
                  <Github className="w-4 h-4" />
                </a>
              )}
              {member.linkedin && (
                <a href={member.linkedin} target="_blank" rel="noreferrer" className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-cyan-400 transition-colors">
                  <Linkedin className="w-4 h-4" />
                </a>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Contact Inquiry Form */}
      <div className="glass-panel p-6 sm:p-8 rounded-3xl border-cyan-500/30 max-w-2xl mx-auto space-y-6">
        <h3 className="font-tech text-xl font-bold text-white border-b border-slate-800 pb-3 text-center">
          SEND AN INQUIRY OR COLLABORATION REQUEST
        </h3>

        {formSubmitted ? (
          <div className="p-6 rounded-2xl bg-emerald-950/40 border border-emerald-500/50 text-emerald-300 text-center font-mono text-xs space-y-2 animate-fadeIn">
            <CheckCircle className="w-8 h-8 text-emerald-400 mx-auto" />
            <p className="font-bold text-sm">INQUIRY TRANSMITTED SUCCESSFULLY!</p>
            <p className="text-slate-400">Our engineering team will respond to your message shortly.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="Your Full Name"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
              />
              <input
                type="email"
                placeholder="Your Email Address"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
              />
            </div>
            <input
              type="text"
              placeholder="Subject (e.g. IEEE Collaboration, Hardware Inquiry)"
              required
              value={formData.subject}
              onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
            />
            <textarea
              placeholder="Message details..."
              rows={4}
              required
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
            />
            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-black font-tech font-bold text-sm tracking-wider hover:scale-[1.02] transition-all shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>TRANSMIT MESSAGE</span>
            </button>
          </form>
        )}
      </div>
    </section>
  );
};

import React, { useState } from 'react';
import { Search, X, ArrowRight, Zap, Box, BookOpen, Calculator } from 'lucide-react';
import { NavTab } from '../types';
import { COMPONENTS_DATA, ARCHITECTURE_NODES, MATH_FORMULAS, RESEARCH_PAPERS } from '../data/projectData';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: NavTab) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose, onNavigate }) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const filteredComponents = COMPONENTS_DATA.filter((c) =>
    c.name.toLowerCase().includes(query.toLowerCase()) || c.workingPrinciple.toLowerCase().includes(query.toLowerCase())
  );

  const filteredArchitecture = ARCHITECTURE_NODES.filter((a) =>
    a.title.toLowerCase().includes(query.toLowerCase()) || a.workingPrinciple.toLowerCase().includes(query.toLowerCase())
  );

  const filteredMath = MATH_FORMULAS.filter((m) =>
    m.title.toLowerCase().includes(query.toLowerCase()) || m.latex.toLowerCase().includes(query.toLowerCase())
  );

  const filteredPapers = RESEARCH_PAPERS.filter((p) =>
    p.title.toLowerCase().includes(query.toLowerCase()) || p.summary.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="glass-panel w-full max-w-2xl rounded-3xl border-cyan-500/40 p-6 bg-[#030712] space-y-6 shadow-2xl">
        {/* Search Header */}
        <div className="relative">
          <Search className="w-5 h-5 text-cyan-400 absolute left-4 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search components, math formulas, IEEE papers, specs..."
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-slate-900 border border-cyan-500/30 rounded-2xl pl-12 pr-12 py-3.5 text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
          />
          <button
            onClick={onClose}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto space-y-4 font-mono text-xs">
          {/* Quick Nav Shortcuts */}
          {!query && (
            <div className="space-y-2">
              <span className="text-[10px] text-slate-500 uppercase font-bold">Quick Navigation Shortcuts</span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { tab: '3d-simulation', label: '3D Simulation', icon: <Box className="w-3.5 h-3.5 text-cyan-400" /> },
                  { tab: 'ems', label: 'Energy EMS', icon: <Zap className="w-3.5 h-3.5 text-emerald-400" /> },
                  { tab: 'dashboard', label: 'Live Telemetry', icon: <Zap className="w-3.5 h-3.5 text-amber-400" /> },
                  { tab: 'components', label: 'Hardware BOM', icon: <Box className="w-3.5 h-3.5 text-cyan-400" /> },
                  { tab: 'math-model', label: 'Math Formulas', icon: <Calculator className="w-3.5 h-3.5 text-purple-400" /> },
                  { tab: 'research', label: 'Research Papers', icon: <BookOpen className="w-3.5 h-3.5 text-blue-400" /> },
                ].map((item) => (
                  <button
                    key={item.tab}
                    onClick={() => {
                      onNavigate(item.tab as NavTab);
                      onClose();
                    }}
                    className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-slate-300 hover:border-cyan-500/40 hover:text-white flex items-center justify-between transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      {item.icon}
                      <span>{item.label}</span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-600" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Search Query Matches */}
          {query && (
            <div className="space-y-3">
              {filteredComponents.map((c) => (
                <div
                  key={c.id}
                  onClick={() => {
                    onNavigate('components');
                    onClose();
                  }}
                  className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-cyan-400 cursor-pointer flex justify-between items-center"
                >
                  <div>
                    <span className="text-[10px] text-cyan-400 uppercase font-bold">COMPONENT</span>
                    <h4 className="font-bold text-white text-sm">{c.name}</h4>
                  </div>
                  <ArrowRight className="w-4 h-4 text-cyan-400" />
                </div>
              ))}

              {filteredArchitecture.map((a) => (
                <div
                  key={a.id}
                  onClick={() => {
                    onNavigate('architecture');
                    onClose();
                  }}
                  className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-cyan-400 cursor-pointer flex justify-between items-center"
                >
                  <div>
                    <span className="text-[10px] text-emerald-400 uppercase font-bold">ARCHITECTURE NODE</span>
                    <h4 className="font-bold text-white text-sm">{a.title}</h4>
                  </div>
                  <ArrowRight className="w-4 h-4 text-emerald-400" />
                </div>
              ))}

              {filteredMath.map((m) => (
                <div
                  key={m.id}
                  onClick={() => {
                    onNavigate('math-model');
                    onClose();
                  }}
                  className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-cyan-400 cursor-pointer flex justify-between items-center"
                >
                  <div>
                    <span className="text-[10px] text-purple-400 uppercase font-bold">MATH EQUATION</span>
                    <h4 className="font-bold text-white text-sm">{m.title}</h4>
                  </div>
                  <ArrowRight className="w-4 h-4 text-purple-400" />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
